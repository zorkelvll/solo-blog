title: Java面试
date: '2019-05-19 11:30:53'
updated: '2019-05-19 11:30:53'
tags: [Java, 面试]
permalink: /articles/2019/05/19/1558236653439.html
---
![](https://img.hacpai.com/bing/20180429.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/18/1542543461271](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/18/1542543461271)

### 背景

https://segmentfault.com/a/1190000004716061

一、

1、Thread和Runnable的区别：

    继承Thread类，实现Runnable接口 - java不支持多继承，但支持多实现，使用Runnable更灵活些；

    Runnable是可以共享数据的，即多个Thread可以同时加载同一个Runnable，runnable里面的资源是共享的！

  

    如何停止一个县线程？线程编写中的一些方法？

  

2、nginx负载均衡：

    轮询、最小连接数、IP hash、权重

  

3、MySQL事务和锁

    事务ACID：

    事务隔离级别-4种：读未提交、读提交（大部分数据库默认隔离级别）、可重读（Mysql）、可串行化

![](https://img-blog.csdn.net/20180714101111202?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3pvcmtlQWNjb3VudA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw== "点击并拖拽以移动")​

    共享锁和排它锁：

    MyISAM和InnoDB的区别：MyISAM类型不支持事务处理等高级处理，而InnoDB类型支持。MyISAM类型的表强调的是性能，其执行数度比InnoDB类型更快，但是不提供事务支持，而InnoDB提供事务支持以及外部键、行级锁等高级数据库功能

  

4、jvm垃圾回收机制的时机：

    引用计数器算法、根搜索算法

  

5、线程安全问题：   

    多线程环境下，多个线程操作共享数据，因此解决办法就是同步，多个线程使用同一个锁对象，具体的有：同步代码块、同步方法、静态同步方法

  

6、dubbo、服务治理：

    https://cloud.tencent.com/developer/article/1078966

    https://www.jianshu.com/p/9d062eceb765

7、ELK工具：elasticsearch、logstash、kibana

  

8、docker、k8s、rancher、swarm

  

9、mybatis的缓存原理：一级缓存sqlSession级别的（默认开启，同一个sqlSession中），二级缓存Mapper级别的（多个sqlSession可以共享的，同一个namespace中）

  

10、缓存问题：

    **缓存穿透：**查一个一定不存在的数据（解决办法，一是**布隆过滤器**即将所有可能存在的数据存在一个足够大的bitmap中，二是简单粗暴地缓存**null结果**且该缓存过期时间设置很小如不超过5分钟）

   ** 缓存雪崩：**同一时刻**大量缓存**过期，给DB带来巨大压力（一是可以在原有失效时间基础之上加一个**随机1~5分钟时间**，二是用**加锁或者队列的方式保证缓存的单线 程（进程）写**，从而避免失效时大量的并发请求落到底层存储系统上）

    **缓存击穿：某一个****缓存**在某个时间点过期的时候，恰好在这个时间点对这个Key有大量的并发请求过来，这些请求发现缓存过期一般都会从后端DB加载数据并回设到缓存，这个时候大并发的请求可能会瞬间把后端DB压垮（**简单分布式互斥锁（mutex key）、“提前”使用互斥锁、不过期(本文)、资源隔离组件hystrix(本文)**）

  

11、如何使得一个栈的查找速度达到O(1)：牺牲空间，利用两个栈，另外一个栈单独用来存储当前栈位置处时已入栈的元素中的最小值，弹出时同时弹出！

  

12、spring bean的加载过程

  

13、spring ioc 和aop

  

14、设计模式

  

  

二、

1、MySQL数据库索引的实现原理 - 平衡树

    支持索引类型-B+树索引、哈希索引、全文索引

    MyISAM和InnoDB均使用B+树（平衡多路查找树）作为 索引结构：InnoDB中数据文件本身就是索引文件，叶节点的data域存储完整的数据记录，索引key即为表的主键，且通过辅助索引查找获取到主键值然后再到主索引中获取到数据记录，是一种聚集索引；而MyISAM则有数据文件和索引文件，叶子节点data域中存储的是数据记录的地址，是一种非聚集索引

2、MySQL索引更新的原理

  

3、MySQL索引失效的情况

    where条件中：or、in、函数、对索引列进行运算（+，-，*，/，! 等）

    where条件中使用比较操作符LIKE和REGEXP，且搜索模板中的第一个字符不是通配符的情况下索引才生效（如LIKE 'abc%'索引生效，LIKE '%abc'索引失效）

    单列索引不存储null值，复合索引不存储全null值，null查询索引无效

     列类型是字符串，如果不将数据使用引号则索引将失效

    JOIN操作时，只有主键和外键的数据类型相同时，索引才生效

  

4、HTTP状态码：

**    200 OK  正常成功处理**

    301 Moved Permantently 永久重定向

    **302 Found 临时重定向**

    **400 Bad Request 请求报文存在语法错误或参数错误**

    401 Unauthorized 发送的请求需要有HTTP认证信息或者是认证失败了

**    403 Forbiddern 对请求资源的访问被服务器拒绝了**

**    404 Not Found 服务器找不到你请求的资源 **

**    500 Internal Server Error 服务内部错误**

  

    204 No Content 请求已成功处理，但没有内容返回

    206 Patial Content 完成了部分GET请求

    503 Service Unavailable 服务器超负载或正停机维护，无法处理请求

  

5、spring中事务的使用方式

    **声明式：**不需要对原有的业务做任何修改，通过在XML文件中定义需要拦截方法的匹配即可完成配置，要求是，业务处理中的方法的命名要有规律，比如setXxx，xxxUpdate等等

    **注解式：**只需要在Spring配置文件中定义一个事务管理对象（如DataSourceTransactionManager），然后加入节点，引用该事务管理对象，然后即可在需要进行事务处理的类和方法使用@Transactional进行标注

  

6、如何自定义一个具有实际意义功能的注解？

    注解声明、注解解析（或者切面处理）、使用注解

注解相关：[https://blog.csdn.net/u010889990/article/details/80333100](https://blog.csdn.net/u010889990/article/details/80333100)

三、

1、乐观锁和悲观锁的区别，如何去实现一个乐观锁？

  

2、concurrentHashMap在jdk1.7和jdk1.8中的区别是什么？

  

3、如何终止一个线程？

  

4、aop不能使用的一些场景？

  

5、如何实现一个spring-boot-starter开箱即用的工程？

  

6、哪些情况下会出现栈溢出OOM？

  

四、

1、多租户系统开发？sass、paas

2、springboot统一异常处理

3、spring security实现权限控制

  

五、

1、dubbo服务注册原理是什么？

2、dubbo服务间负载均衡是怎么实现的？dubbo熔断如何实现的？

3、mysql索引为什么使用的是B+二叉树？

4、蚂蚁基本上使用的都是sofa分布式框架？

5、为什么要使用zookeeper？zookeeper有什么优势？

6、做过前端开发，有自己的作品吗？网站域名是什么？

7、分布式系统中各个日志如何进行同步的？怎么实现统计网站访问量等图形界面的？