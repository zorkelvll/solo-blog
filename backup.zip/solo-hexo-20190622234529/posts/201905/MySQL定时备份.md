title: MySQL定时备份
date: '2019-05-19 11:08:50'
updated: '2019-05-19 11:08:50'
tags: [MySQL]
permalink: /articles/2019/05/19/1558235330249.html
---
![](https://img.hacpai.com/bing/20190104.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

<br />
<br />
<br />
### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2019/01/27/1548594908494](https://zorkelvll.cn/blogs/zorkelvll/articles/2019/01/27/1548594908494)

### 一、背景
&nbsp;&nbsp;&nbsp;&nbsp;对于一般的开发者而言，既无力使用昂贵的阿里云等云厂商提供数据库服务，但又常常苦于无法保证自己在服务器上安装的mysql数据库中数据的安全性或者有效备份特性，因此我们将利用crontab实现定时备份个人mysql数据库文件到个人的七牛云存储中去！PS:仅对于开发者个人网站中一些不重要的数据，而各位公司内部的数据谨慎存储到第三方云存储空间！

### 二、操作

* 确认crontab服务开启：service crond status
* 确认系统中gzip以及mysqldump命令可正常执行
* 安装七牛云命令行工具qshell:
    
    cd ~/app & wget http://devtools.qiniu.com/qshell-v2.3.6.zip

    yum install unzip

    unzip -o -d ./qshell qshell-v2.3.6.zip

    cd qshell & mv qshell_linux_x64 qshell

    vim ~/.bashrc 添加配置项：export PATH=$PATH:/root/app/qshell

    source ~/.bashrc

* 注册七牛云账号并完成实名认证，[官方注册](https://portal.qiniu.com/signup?code=3ljd2js9rgymq)

* 使用qshell配置七牛云账号：qshell account AK SK   其中的AK和SK为注册七牛云账号的key  并在控台新建一个存储空间backup

* 安装开启命令自动补全：yum install bash-completion -y
* 创建存放脚本以及数据库dump备份文件存储目录地址：mkdir ~/data/backup/sql & mkdir ~/scripts

* 编辑备份脚本文件~/scripts/baksql.sh，内容如下:

```bash
#!/bin/sh
# mysql data backup script
#
# use mysqldump --help,get more detail.

dbname=yourdatabasename
user=mysqluser
password=mysqlpassword
bakDir=~/data/backup/sql
logFile=~/data/backup/pipe-blog-bak.log
datetime=`date +%Y%m%d%H%M%S`
keepDay=7

echo "-------------------------------------------" >> $logFile
echo $(date +"%y-%m-%d %H:%M:%S") >> $logFile
echo "--------------------------" >> $logFile
cd $bakDir
bakFile=$dbname.$datetime.sql.gz
mysqldump -u$user -p$password $dbname | gzip > $bakFile
echo "数据库 [$dbname] 备份完成" >> $logFile
echo "$bakDir/$bakFile" >> $logFile
echo "开始上传备份文件至七牛云存储" >> $logFile
/root/app/qshell/qshell rput backup database/$bakFile $bakFile --overwrite | sed -r "s/\x1B\[([0-9]{1,2}(;[0-9]{1,2})?)?[m|K]//g" >> $logFile 2>&1
echo "删除${keepDay}天前的备份文件" >> $logFile
find $bakDir -ctime +$keepDay >> $logFile
find $bakDir -ctime +$keepDay -exec rm -rf {} \;
echo " " >> $logFile
echo " " >> $logFile
```

* 将baksql.sh脚本添加到crontab定时器中去执行：

    cd /etc/cron.d
    
    vim baksql.cron 并添加如下内容

```bash
#每天凌晨2点执行备份脚本
0 2 * * * /root/scripts/baksql.sh
```

    crontab baksql.cron

    crontab -l  #查看定时任务

* 七牛云上查看定时备份存在的文件：

![imagepng](https://img.hacpai.com/pipe/zorke/zorke/zorke/d41a46be6d124cfe8b751e23bab93171.png)

* 下载之后可执行解压命令进行解压： gunzip pipe-blog.20190126020001.sql.gz

<br />
<br />
<br />