title: 阿里云主机搭建B3log Pipe博客系统
date: '2019-05-19 11:46:10'
updated: '2019-05-19 11:46:10'
tags: [CentOS]
permalink: /articles/2019/05/19/1558237570806.html
---
![](https://img.hacpai.com/bing/20180325.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/09/1541725358538](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/09/1541725358538)

&nbsp;&nbsp;&nbsp;&nbsp;阿里云主机服务器系统选择为CentOS7.4，本文主要是记录利用该主机搭建B3log Pipe博客系统的过程！

1、基本工具

    yum install gcc gcc-c++

2、golang环境安装及配置

[http://caizhaoke.cn/blogs/zorke/articles/2018/11/02/1541171777964](http://caizhaoke.cn/blogs/zorke/articles/2018/11/02/1541171777964)

3、mysql安装

[http://caizhaoke.cn/blogs/zorke/articles/2018/11/02/1541171868657](http://caizhaoke.cn/blogs/zorke/articles/2018/11/02/1541171868657)

4、nginx安装

[http://caizhaoke.cn/blogs/zorke/articles/2018/11/02/1541171920974](http://caizhaoke.cn/blogs/zorke/articles/2018/11/02/1541171920974)