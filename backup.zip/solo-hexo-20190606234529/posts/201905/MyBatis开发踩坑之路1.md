title: MyBatis开发踩坑之路1
date: '2019-05-19 11:41:03'
updated: '2019-05-19 11:41:03'
tags: [MyBatis]
permalink: /articles/2019/05/19/1558237263401.html
---
![](https://img.hacpai.com/bing/20180501.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/15/1542213094869](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/15/1542213094869)

### 背景
&nbsp;&nbsp;本文主要是介绍在开发过程中，使用mybatis所遇到的坑，仅供自己记录查询以及各位猿友借鉴！

**场景3：**mybatis-xml动态查询条件中实现if else的效果

SQL写法

        <where>
            <if test="sInfoWindcode != null and sInfoWindcode != ''">
                AND a.s_info_windcode = #{sInfoWindcode}
            </if>
            <if test="sInfoWindcode == null || sInfoWindcode == ''">
                <![CDATA[ LIMIT 50 ]]>
            </if>>
        </where>

或者

        <choose>
            <when test="processStatus != null && processStatus != '' && processStatus != '-110'">
               and process_status = #{processStatus,jdbcType=VARCHAR} 
            </when>
            <otherwise>
                and process_status != 1
            </otherwise>
        </choose>


**场景2：**mybatis-xml查询条件字段的值是一个数组，也即前端的条件筛选的值可以多个

参数定义：

    private String[] marketListBoardName;


SQL写法：

    <if test="marketListBoardName != null and marketListBoardName != ''">
      AND ad.MARKET_LISTBOARDNAME IN
      <foreach collection="marketListBoardName" index="index" item="item" open="(" separator="," close=")">
        #{item}
      </foreach>
    </if>

      

**场景1：**mybatis-xml查询条件字段的值是数字字符串如1或者y，如下写法的判断条件将不起作用

    <if test="type == '1'">
      AND a.S_DIV_PROGRESS != '3'
    </if>
    <if test="type == 'y'">
      AND a.S_DIV_PROGRESS != '3'
    </if>

更改为：


    <if test='type == "1"'>
      AND a.S_DIV_PROGRESS != '3'
    </if>
    <if test="type == '1'.toString()">
      AND a.S_DIV_PROGRESS != '3'
    </if>
    <if test='type == "y"'>
      AND a.S_DIV_PROGRESS != '3'
    </if>