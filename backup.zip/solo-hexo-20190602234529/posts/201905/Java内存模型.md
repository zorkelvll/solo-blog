title: Java内存模型
date: '2019-05-19 11:31:45'
updated: '2019-05-19 11:31:45'
tags: [Java]
permalink: /articles/2019/05/19/1558236705142.html
---
![](https://img.hacpai.com/bing/20181003.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

关键词：**线程、主内存、工作内存、JVM内存模型**

 ### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/18/1542543337908](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/18/1542543337908)


**一、概述**

    所有线程共享主内存

    每个线程有自己的工作内存（也即执行空间：主要包括两部分，一是属于该**线程私有的栈**和对主存部分变量**拷贝的寄存器**(包括程序计数器PC和cup工作的高速缓存区)）

    cpu计算时从内存中读取数据的优先顺序依次是：寄存器 -> 高速缓存 -> 内存

[https://blog.csdn.net/javazejian/article/details/72772461](https://blog.csdn.net/javazejian/article/details/72772461)

[http://rainyear.iteye.com/blog/1734311](http://rainyear.iteye.com/blog/1734311)