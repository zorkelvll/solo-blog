title: Git及git工具的使用
date: '2019-05-19 11:37:47'
updated: '2019-05-19 11:37:47'
tags: [Git]
permalink: /articles/2019/05/19/1558237067517.html
---
![](https://img.hacpai.com/bing/20180827.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/18/1542507011212](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/18/1542507011212)

### 背景
&nbsp;&nbsp;&nbsp;&nbsp;本文主要是介绍git的一些使用命令、操作小技巧，以及git图形界面工具TortoiseGit\Sourcetree、代码统计分析工具gitstats等的使用！

### 一、Git

1、推送本地分支到远端指定分支：

如：将本地dev分支push到远端的master分支：git push origin dev:master

       将本地dwzq分支push到远端的dwzq分支：git push origin dwzq:dwzq

  IDEA中将本地dwzq分支push到origin-dwzq远端的dev分支：git push origin-dwzq dwzq:dev

### 二、TortoiseGit

1、背景

  在使用git以及windows下git图形工具TortoiseGit的过程，经常会存在一些坑比如

（1）、使用TortoiseGit 首次pull代码的时候，需要输入账户密码（如果一不小心输入的是错误的密码），但是TortoiseGit会记住账户密码，导致后续重新拉取代码的时候不再出现输入账户密码的界面，然后一直拉取错误失败


2、TortoiseGit清除密码

  tortotiseGit - windows下右击 -> tototiesGit -> setting -> git -> 编辑系统gitconfig，把\[credential\] XXXX=manager 直接删除并保存，重新git pull拉取代码的时候则会出现提示输入密码的那个弹出框


### 三、Gitstats

1、背景

    项目开发结束后，由于需要对在一个项目中各个开发人员提交的代码进行一个大致的统计分析，因此需要利用一些工具如gitstats实现对git仓库中项目代码的统计和分析；

    （1）在mac环境下，尝试使用gitstats工具遇到以下两个问题：

*       由于自己在系统中已经安装了python3，而gitstats的运行需要python2环境，因此需要涉及到系统中python2和python3共存进行管理  ->  因此，采用Anaconda3进行管理
*       在mac系统最初是尝试使用brew安装gitstats（brew install --HEAD homebrew/head-only/gitstats），但是安装失败且报错"Error: homebrew/head-only was deprecated. This tap is now empty as all its formulae were migrated."  -> 因此，采用github-gitstats源码直接使用gitstats命令功能

    （2）在linux环境下，…………

  

2、Mac下-使用

  1、gitstats-github源码下载：[https://github.com/hoxu/gitstats](https://github.com/hoxu/gitstats) ，如下载到本地文件夹~/github/gitstats

  2、在Anaconda3管理界面添加一个新的环境（python2.7），然后在该环境选项run按钮右击执行open terminal，打开python2.7终端界面

  3、生成demo-project项目的git代码统计分析结果，在2中终端窗口执行命令：

~/github/gitstats/gitstats ~/projects/demo-project ~/data/gitstats/result/demo-project-gitstats

  4、浏览器中打开~/data/gitstats/result/demo-project-gitstats中的index.html静态页面，可以查看demo-project项目git相关的统计分析结果，如

![](https://img-blog.csdn.net/20180725104559891?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3pvcmtlQWNjb3VudA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)​
  
  
3、Linux下-使用