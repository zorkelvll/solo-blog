title: Spring&SpringBoot注解
date: '2019-05-19 11:31:22'
updated: '2019-05-19 11:31:22'
tags: [Spring, Springboot]
permalink: /articles/2019/05/19/1558236682778.html
---
![](https://img.hacpai.com/bing/20180715.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

**关键词：**注解、@SpringBootApplication、@EnableAutoConfiguration

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/18/1542543402813](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/18/1542543402813)


**一、Springboot注解：**

**    @SpringBootApplication：**

        Springboot的入口注解，是多个注解的组合，其中比较重要的是**@EnableAutoConfiguration**注解，即可自动化配置，这是SpringBoot可以方便快捷地新建和启动一个项目的关键

    **@EnableAutoConfiguration：**

        该注解比较重要的是导入了一个**开启可自动化配置导入选择器**功能类，即**@Import({EnableAutoConfigurationImportSelector.class})**，该类继承了自动配置导入选择器类AutoConfigurationImportSelector.class，类中方法selectImports()读取各配置项！

有关该@SpringBootApplication注解的详细分析过程可见，[springboot自动化配置](https://blog.csdn.net/weixin_39800144/article/details/79358643)