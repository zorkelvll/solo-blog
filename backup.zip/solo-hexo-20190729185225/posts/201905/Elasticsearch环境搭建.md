title: Elasticsearch环境搭建
date: '2019-05-19 11:05:01'
updated: '2019-05-19 11:05:01'
tags: [ELK, 运维]
permalink: /articles/2019/05/19/1558235101862.html
---
![](https://img.hacpai.com/bing/20180430.jpg?imageView2/1/w/768/h/432/interlace/1/q/100)

<br />
<br />
<br />
### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2019/03/09/1552144573456](https://zorkelvll.cn/blogs/zorkelvll/articles/2019/03/09/1552144573456)

### 背景
&nbsp;&nbsp;&nbsp;&nbsp;本文主要是介绍Elasticsearch环境的搭建过程，elasticsearch-6.6.1

### 单节点安装
    cd /usr/local   #root用户
    wget https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-6.6.1.tar.gz  #下载elasticsearch-6.6.1.tar.gz
    tar -zxvf elasticsearch-6.6.1.tar.gz #解压
    cd elasticsearch-6.6.1/
    ./bin/elasticsearch  #运行报错

运行时报错：StartupException: java.lang.RuntimeException: can not run elasticsearch as root

解决办法：创建非root用户并以该用户获取该文件夹权限

```
groupadd es
useradd es -g es -p es
chown es:es /usr/local/elasticsearch-6.6.1/
chown es elasticsearch-6.6.1 -R
su es
./bin/elasticsearch

```

注意：同样需要保证es用户下具有java环境

    ./bin/elasticsearch -d  #以后台进程形式启动
    curl localhost:9200 #默认端口9200，访问之存在一个json数据体返回，则可验证elasticsearch单机环境启动成功
    vim ./config/elasticsearch.yml  #配置path.data和path.log分别为 ~/elasticsearch/data  和 ~/elasticsearch/logs
    vim ./config/elasticsearch.yml  #配置端口9200以及外网可以访问network.host: 0.0.0.0配置项

问题1    运行时报错：[1]:maxvirtualmemoryareasvm.max_map_count[65530]istoolow,increasetoatleast[262144]

解决办法：

```
vim /etc/sysctl.conf #root用户编辑该配置文件，并添加如下代码
# for elasticsearch
vm.max_map_count=655360

sysctl -p  #使其生效
```

问题2    运行时报错：
[1]: max file descriptors [65535] for elasticsearch process is too low, increase to at least [65536]

解决办法：

```
vim /etc/security/limits.conf   #root用户编辑该配置文件，并添加或修改如下代码
* soft nofile 65536
* hard nofile 131072
* soft nproc 2048
* hard nproc 4096 
```


问题3   使用supervisor启动时，查看日志仍然报下面的错误
[1]: max file descriptors [65535] for elasticsearch process is too low, increase to at least [65536]

```
vim /etc/supervisord.d/elasticsearch.conf   #root用户编辑该配置文件，并添加或修改如下代码

[supervisord]
minfds=65536
minprocs=32768

[program:es]
process_name=%(program_name)s_%(process_num)02d
directory=/usr/local/elasticsearch-5.6.3/
command=/usr/local/elasticsearch-5.6.3/bin/elasticsearch
;autostart=true
autorestart=false
user=testuser
numprocs=1
```


=>云服务器端口开放9200之后，外网访问ip:9200即可访问成功
 

### 集群安装

<br />
<br />
<br />