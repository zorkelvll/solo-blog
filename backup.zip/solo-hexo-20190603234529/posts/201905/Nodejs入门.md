title: Nodejs入门
date: '2019-05-19 11:02:42'
updated: '2019-05-19 11:02:42'
tags: [JS]
permalink: /articles/2019/05/19/1558234962174.html
---
![](https://img.hacpai.com/bing/20181215.jpg?imageView2/1/w/768/h/432/interlace/1/q/100)

<br />
<br />
<br />
&nbsp;&nbsp;&nbsp;&nbsp;本文主要是作为自己系统地整理nodejs入门知识点，以弥补自身之前对nodejs相关项目开发只能模仿而不能自主开发或者创造的巨大技术缺陷！

### 环境工具
* nvm ： nodejs版本管理工具
* npm ： nodejs包管理工具
* nrm ： npm registry管理工具

### 基本概念

* 异步：nodejs是一种依托于回调实现的异步编程，回调函数一般作为执行异步操作函数的最后一个参数出现（异步async ~ 非阻塞，同步sync ~ 阻塞），并且回调函数接收错误对象作为第一个参数
* 事件驱动机制：nodejs采用“观察者模式 + 异步回调”的事件驱动模型，解决nodejs单进程单线程应用的并发性能问题；如，可使用events模块的EventEmitter类来绑定和监听事件
* 模块系统：在nodejs中，一个模块 = 一个文件，该文件可以是js代码、json文件或编译过的c/c++扩展；模块系统使得nodejs文件可以相互调用，模块是nodejs应用的基本组成部分
* 函数：在js中，一个函数可以作为另一个函数的参数；匿名函数，即将一个函数作为变量传递，不需要遵循“先定义，再传递”，直接在接收参数的地方定义函数且可以不用给函数起名字，因此称之为匿名函数，例如http.createServer()方法的参数使用是传递了一个匿名函数
* 路由：url模块 + querystring模块，以实现路由并解析URL地址
* 全局对象：全局变量即为全局对象的属性（注意：永远使用var定义变量以避免引入全局变量）


### 常见类

* EventEmitter

events模块仅提供一个对象events.EventEmitter，该对象核心就是事件触发(emit-触发一个事件)与事件监听器(on-绑定事件函数)功能的封装

EventEmitter的每个事件 = 唯一的事件名 + 若干个事件监听器，，注册到这个事件（即事件名相同的事件为同一个事件）的事件监听器会被依次调用

一个事件 即 为一个事件名称固定的即为一个事件

error事件：一般要为会触发 error 事件的对象设置监听器，避免遇到错误后整个程序崩溃

继承EventEmitter ：一般不会直接使用EventEmitter，而是在对象中去继承它，如fs\http\net等模块，只要是支持响应事件的核心模块都是EventEmitter的子类

* Buffer

js语言中只有字符串数据类型，没有二进制数据类型；但对于处理向TCP流或文件流时，必须使用到二进制数据，因此在nodejs中定义了Buffer类用以创建一个专门存放二进制数据的缓存区

Buffer.from('aokaytech','ascii');//用于表示编码字符的序列，如UTF-8,UCS2，Base64、十六进制编码

* Stream

nodejs中Stream有四种流类型：Readable可读操作、Writable可写操作、Duplex可读可写操作、Transform操作被写入数据然后读出结果

所有Stream对象均是EventEmitter的实例，常用事件有：data有数据可读时触发、end没有更多数据可读时触发、error在接收和写入过程中发生错误时触发、finish所有数据已被写入到底层系统时触发

常用的流操作：从流中读取数据、写入流、管道流、链式流


### nodejs模块

* 模块：

nodejs提供了exports（是模块公开的接口）和require（用于从外部获取一个模块的接口，即所获取模块的exports对象；./表示当前目录，nodejs默认文件后缀为js）两个对象，其中exports或者以exports.xxx = ……形式定义模块公开接口，或者module.exports =  Xxx形式定义对象本身即在外部引用该模块时输出为对象本身而不是原先的exports

模块加载流程（也即，require方法的文件查找策略）：nodejs中有4类模块（原生模块 + 3种文件模块）：从文件模块缓存中加载、从原生模块加载、从文件加载

加载流程如下图：
![image.png](https://img.hacpai.com/file/2019/03/image-995cdd35.png)

require支持以下四种参数：

http、fs、path等原生模块；

./mod或../mod，相对路径的文件模块

/pathtomodule/mod，绝对路径的文件模块

mod，非原生模块的文件模块


* http模块

```
createServer(function(req,res){}).listen(8888);
```

* fs模块

```
readFileSync('file.txt');

readFile('file.txt',function(err,data){});

```

* events模块

```
//EventEmitter类
eventEmitter.on('eventName',eventHandler);  //绑定事件及事件处理程序，等同于addListener方法
eventEmitter.emit('eventName');//触发eventName事件监听器

eventEmitter.emit('error');//触发error事件监听器：若事件队列中出现一个未绑定事件则触发error事件，若未绑定 error事件则程序抛出异常结束执行

listenerCount();//等价于eventEmitter.listeners('connection').length
once();
……
```

* url模块

* querystring模块

* util模块

```
util.inherits(constructor, superConstructor); //实现对象间原型继承的函数
util.inspect(object,[showHidden],[depth],[colors]);//将任意对象转换为字符串，常用于调试和错误输出
util.isArray(object);//判断是否数组
util.isRegExp(object);//判断是否正则表达式
util.isDate(object);//判断是否日期
util.isError(object);//判断是否错误对象
```

* os模块
* path模块
* net模块
* dns模块
* domain模块



### 扩展
* global对象

__filename ： 当前正在执行的脚本的文件名（含路径）
__dirname ： 当前正在执行的脚本所在目录
setTimeout(cb,ms)：在指定的毫秒ms后执行一次指定函数cb，返回一个代表定时器的句柄
setInterval(cb,ms)：在指定的毫秒ms后重复多次执行指定函数cb，返回一个代表定时器的句柄；直至clearInterval(t)函数被调用清除定时器
clearTimeout(t)：停止一个之前setTimeout创建过的定时器t

console：提供控制台标准输出，log\info\error\warn\dir\time\timeEnd\trace\assert

process：描述当前nodejs进程状态的对象，exit\beforeExit\uncaughtException\Signal

* nodejs多进程
* nodejs连mysql
* nodejs连mongodb


<br />
<br />
<br />