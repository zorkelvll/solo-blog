title: Javascript 入门
date: '2019-05-19 11:02:12'
updated: '2019-05-19 11:02:12'
tags: [JS]
permalink: /articles/2019/05/19/1558234932437.html
---
![](https://img.hacpai.com/bing/20180906.jpg?imageView2/1/w/768/h/432/interlace/1/q/100)

<br />
<br />
<br />
&nbsp;&nbsp;&nbsp;&nbsp;本文主要是作为自己系统地整理javascript入门基础知识点，以弥补自身之前对javascript相关项目开发只能模仿而不能自主开发或者创造的巨大技术缺陷！

### functions

* setTimeout

```
setTimeout(
function(){
 dosomething();
},1000
);
```


### tips


### 姊妹篇

* [nodejs入门](https://www.zorkelvll.cn/blogs/zorkelvll/articles/2019/03/31/1554005844303)

<br />
<br />
<br />