title: JavaScript小技巧1
date: '2019-05-19 11:39:21'
updated: '2019-05-19 11:39:21'
tags: [JS]
permalink: /articles/2019/05/19/1558237160997.html
---
![](https://img.hacpai.com/bing/20180319.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/17/1542461611996](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/17/1542461611996)

### 背景
&nbsp;&nbsp;&nbsp;&nbsp;本文主要是介绍在使用javascript过程中的一些小技巧，诸如如何在chrome浏览器控制台中引入外部js文件之类的……

1、在Chrome浏览器控制台中引入外部js文件

例如需要在控制台中使用如下js文件

1、chrome浏览器console控台引入外部js文件如

`https://cdn.jsdelivr.net/npm/sockjs-client@1/dist/sockjs.min.js`

在console中输入：


    var script = document.createElement('script');
    script.src = "https://cdn.jsdelivr.net/npm/sockjs-client@1/dist/sockjs.min.js";
    document.getElementsByTagName('head')[0].appendChild(script);

则在控制台中引入sockjs.min.js文件成功