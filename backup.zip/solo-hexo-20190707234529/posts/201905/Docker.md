title: Docker
date: '2019-05-19 11:09:17'
updated: '2019-05-19 11:09:17'
tags: [Docker]
permalink: /articles/2019/05/19/1558235357724.html
---
![](https://img.hacpai.com/bing/20171213.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

<br />
<br />
<br />
### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2019/01/21/1548041077470](https://zorkelvll.cn/blogs/zorkelvll/articles/2019/01/21/1548041077470)

### 一、背景
&nbsp;&nbsp;&nbsp;&nbsp;对于大部分程序员而言（当然喽，可能只是我一个个例），对docker的初步认识可能就是安装软件起来非常方便，进一步就是学会使用几个docker命令，最多谢谢compose文件；但是，对docker相关的基本概念、思想以及k8s编排工具等，可能最多也只是听过，却从来都没有深入研究过，因此为了完善自己对docker相关的理解而在此进行记录！

### 二、基本概念
#### 1、容器
通俗地讲，容器就是一个存放东西的地方；比如，在java中容器是存放java对象的集合如List；在Spring中IOC容器用于存放和管理各种bean对象；而在软件领域，容器则是存放软件的一组环境，主要是将软件打包成标准化单元，以用于开发、交付和部署

#### 2、虚拟机
容器是对操作系统层面进行虚拟化的，容器间共享同一套系统资源；而虚拟机则是对硬件层面进行虚拟化的，然后在其上运行一套完整操作系统！

#### 3、Docker
Docker是一种在操作系统层面的虚拟化容器，实现对进程的封装和隔离

#### 4、镜像  VS  容器  VS  仓库
* 镜像Image：一个特殊的文件系统
* 容器Container：镜像运行时的实体
* 仓库Repository：集中存放镜像文件的地方


### 三、docker核心技术
#### ！1、命名空间Namespaces
命名空间Namespaces是linux提供的一种用于分离进程树、网络接口、挂载点以及进程间通信等资源的方法！

目标是“希望在同一台机器上的不同服务能够做到完全隔离的效果，也即各个服务就像是运行在多台不同的机器上一样”，对不同的容器实现了隔离，保证各个服务之间互不影响和安全性

七种不同的命名空间：以在创建新的进程时设置新进程应该在哪些资源上与宿主机进行隔离

* CLONE_NEWCGROUP
* CLONE_NEWIPC
* CLONE_NEWNET
* CLONE_NEWNS
* CLONE_NEWPID
* CLONE_NEWUSER
* CLONE_NEWUTS

#### 2、进程
进程即一个正在执行的程序，也是在现代分时系统中的一个任务单元！

#### 3、网络
docker提供了四种不同的网络模式Host、Container、None和Bridge模式

默认为网桥Bridge模式，该模式除了分配隔离的网络命名空间外，还会为所有的容器设置IP地址

#### 4、libnetwork
整个网络部分的功能都是通过docker拆分出来的libnetwork实现的，它提供了一个连接不同容器的实现，同时也能够为应用给出一个能够提供一致的编程接口和网络层抽象的容器网络模型

三个主要组件：Sandbox，Endpoint，Network

在容器网络模型中，每一个容器内部都包含一个sandbox，其中存储着当前容器的网络栈配置，包括容器的接口、路由表和DNS设置；linux使用命名空间实现这个sandbox

每一个sandbox中都可能会有一个或多个endpoint，在linux上就是一个虚拟的网卡veth，sandbox通过endpoint加入到对应的网络中（该网络可能是linux网桥或vlan）

#### 5、挂载点
在新的进程中创建隔离的挂载点命名空间需要在clone函数中传入CLONE_NEWNS，以使得子进程可以得到父进程挂载点的拷贝；如果不传入这个参数，子进程对文件系统的读写就都会同步回父进程以及整个主机的文件系统

如果一个容器需要启动，那么它一定需要提供一个根文件系统rootfs，容器需要使用这个文件系统来创建一个新的进程，所有二进制的执行都必须在这个根文件系统中

#### 6、chroot
通过改变当前系统的根目录，限制用户的权利，建立一个与原系统完全隔离的目录结构

#### ！7、CGroups
Control Groups 能够隔离宿主机器上的物理资源，如CPU、内存、磁盘I/O和网络带宽

每一组CGroup都是一组被相同的标准和参数限制的进程，不同的CGroup之间有层级关系

#### ！8、UnionFS
Linux的命名空间和控制组分别解决了不同资源隔离的问题，前者解决了进程、网络以及文件系统的隔离，后者实现了CPU、内存等资源的隔离；；除此之外，还有一个非常重要的问题，即是镜像问题需要解决

docker镜像就是一个文件

#### 9、存储驱动

#### 10、AUFS

<br />
<br />
<br />