title: vi/vim操作之备查
date: '2019-05-19 10:46:25'
updated: '2019-05-19 10:46:25'
tags: [运维]
permalink: /articles/2019/05/19/1558233985862.html
---
![](https://img.hacpai.com/bing/20180106.jpg?imageView2/1/w/768/h/432/interlace/1/q/100)

<br />
<br />
<br />
&nbsp;&nbsp;&nbsp;&nbsp;本文主要介绍自己在使用vim时候，针对一些常用场景所使用的命令组合以及些许小技巧，仅供直接快速备查之需要！

### 场景
#### 日志定位
```
    vim aa-system.log #打开编辑器
    :set number #设置显示行号
    G #跳至最后一行
    ?querykeywords #向上搜索关键词
    N #向上重复搜索

    ctrl + b  #向上移动一页
    ctrl + d  #向下移动半页
```
#### 按行截取
```
    set number #显示行
    : 16, 27 w subfile.log      #截取16到27行到另外一个文件subfile.log中
    : 16, 27 w >> subefile.log  #截取16到27行，并追加到另外一个文档subfile.log中
``` 

### 命令大集合
```
    gg #跳至首行

    :set nonumber #关闭显示行号

    ? #向前搜索
    / #向后搜索

    ctrl + e #上滚
    ctrl + y #下滚

    yy #拷贝
    Y #拷贝行
    P #粘贴(前)
    p #粘贴(后)

    ctrl + f #向下移动一页
    ctrl + u #向上移动半页
    ctrl + b  #向上移动一页
    ctrl + d  #向下移动半页

    less命令
```


参考链接：

[http://www.runoob.com/linux/linux-vim.html](http://www.runoob.com/linux/linux-vim.html)
<br />
<br />
<br />