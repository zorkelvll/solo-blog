title: Jenkins环境安装
date: '2019-05-19 11:50:12'
updated: '2019-05-19 11:50:12'
tags: [运维]
permalink: /articles/2019/05/19/1558237812600.html
---
![](https://img.hacpai.com/bing/20180830.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541172247201](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541172247201)

### 背景
&nbsp;&nbsp;本文将介绍在Linux-CentOS7.2系统环境中安装部署Jenkins2.121.2，以及说明jenkins的配置使用和自动构建操作……


**一 环境**

*   centos7.2
*   tomcat9.0.10
*   Jenkins2.121.2 war包
*   jdk 1.8.0_151

**二 安装**

* 将Jenkins2.121.2的war包jenkins.war文件直接移动至tomcat9.0.10下的webapps目录下

* 启动tomcat：./bin/startup.sh 启动tomcat，浏览器中访问地址：{ip}:{port}/jenkins/，如[http://127.0.0.1:8080/jenkins/](http://47.97.18.141:8080/jenkins/)



**三 初始化配置及插件管理**

1、首次登录[http://127.0.0.1:8080/jenkins/](http://47.97.18.141:8080/jenkins/)界面，输入初始密码（vim /root/.jenkins/secrets/initialAdminPassword  该文件中内容即为初始密码）

2、首次登录jenkins执行初始化，选择推荐的插件初始化管理配置，然后等待该配置完成即可，等待过程中的界面如下

![](https://img-blog.csdn.net/20180812110220138?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3pvcmtlQWNjb3VudA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw== "点击并拖拽以移动")​

3、接着在2完成之后，保存并继续在新的界面，可以主动设置一个新的管理员账户和密码，并用新的管理员账号密码登录

4、必要的其他插件安装-菜单 “系统管理 -> 管理插件”，添加如下三个必须的插件：

*   Git plugin(Git 源码管理插件)【在2中已经安装】
*   Maven Integration(maven 打包插件)
*   Publish Over SSH(远程访问的SSH插件)

  

**四 系统配置**

1、配置邮件：系统管理 -> 系统设置 -> Jenkins Location：设置系统管理员邮件地址，如admin@aokay.tech 

  
**五 全局工具配置：系统管理 -\> 全局工具配置**

1、jdk

![](https://img-blog.csdn.net/20180812114137941?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3pvcmtlQWNjb3VudA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
2、maven

![](https://img-blog.csdn.net/20180812130009263?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3pvcmtlQWNjb3VudA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
maven configuration

![](https://img-blog.csdn.net/2018081213143064?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3pvcmtlQWNjb3VudA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

3、git

![](https://img-blog.csdn.net/201808121313565?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3pvcmtlQWNjb3VudA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)