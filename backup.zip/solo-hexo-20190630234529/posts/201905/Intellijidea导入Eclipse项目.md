title: Intellij idea导入Eclipse项目
date: '2019-05-19 11:08:14'
updated: '2019-05-19 11:08:14'
tags: [IDE]
permalink: /articles/2019/05/19/1558235294562.html
---
![](https://img.hacpai.com/bing/20171128.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

<br />
<br />
<br />
### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2019/01/29/1548775353533](https://zorkelvll.cn/blogs/zorkelvll/articles/2019/01/29/1548775353533)

### 背景
&nbsp;&nbsp;&nbsp;&nbsp;本文主要是记录将一个eclipse web项目导入到idea并运行启动的一个过程

### 1、导入

* IDEA 导入并选择 eclipse方式导入项目文件夹；

* 然后选择设置项目的jdk版本；

* 然后在项目结构中设置module的SDK，并把把红色org开头的都remove掉（org开头的是eclipse的配置文件）

* 然后，点击 Facet→Web（不存在web，则将该项目+添加进去），然后点击右边的加号把文件选中此项目中web.xml或者修改路径为该项目中的web.xml，然后是web resource directory更改为该web目录。之后点击apply，最后点击 Create Artifact。

### 2、配置tomcat

tomcat9需要配置用户重启之后才可以访问web页面

    vim ~/app/apache-tomcat-9.0.14/conf/tomcat-users.xml   #并添加如下内容：
    <role name="manager-gui"/> 
    <user name="yourname" password="yourpwd" roles="manager-gui"/>


### 3、字符集问题
Error:(1, 1) java: 非法字符: '\\ufeff'

解决办法：把UTF-8 转 UTF-16再转回来

<br />
<br />
<br />