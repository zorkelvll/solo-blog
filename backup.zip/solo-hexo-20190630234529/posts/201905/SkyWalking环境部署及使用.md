title: SkyWalking环境部署及使用
date: '2019-05-19 11:01:12'
updated: '2019-05-19 11:01:12'
tags: [运维]
permalink: /articles/2019/05/19/1558234872714.html
---
![](https://img.hacpai.com/bing/20180412.jpg?imageView2/1/w/768/h/432/interlace/1/q/100)

&nbsp;&nbsp;&nbsp;&nbsp;本文主要是记录使用SkyWalking实现应用性能监控过程中，对于SkyWalking环境搭建部署以及使用过程中的一些问题进行记录！

说明：elasticsearch环境安装及配置可见[ELK 日志系统环境搭建](https://www.zorkelvll.cn/blogs/zorkelvll/articles/2019/03/20/1553062484473)中相应部分即可

elasticsearch-6.6.1
skywalking-6.0.0-GA

### 下载
```
cd /usr/local #root用户

wget http://mirrors.tuna.tsinghua.edu.cn/apache/incubator/skywalking/6.0.0-GA/apache-skywalking-apm-incubating-6.0.0-GA.tar.gz

tar -zxvf apache-skywalking-apm-incubating-6.0.0-GA.tar.gz
chown es:es /usr/local/apache-skywalking-apm-incubating/ -R
```
### 配置
```
cd /usr/local/apache-skywalking-apm-incubating/config  #es用户
vim application.yml  #修改application.yml 内容如下图
```
![image.png](https://img.hacpai.com/file/2019/04/image-503d6686.png)

![image.png](https://img.hacpai.com/file/2019/04/image-fd96d8c9.png)
【先以h2数据库作为存储，可以成功，不报/graphql 500错误（当然这是后话了），此处先以此配置保证该skywalking不存在错误，之至于es配置将在下一步继续解决该问题】


```
cd ../webapp/ 
vim webapp.yml  #修改webapp.yml 内容如下图
```
![image.png](https://img.hacpai.com/file/2019/04/image-156eb668.png)


### 运行
```
cd ../bin/
./startup.sh # 访问ip:8080  (默认端口8080以及用户名密码admin)
```

### 配置(es6为存储)
```
cd /usr/local/apache-skywalking-apm-incubating/config  #es用户
vim application.yml  #修改application.yml 内容如下图

```
![image.png](https://img.hacpai.com/file/2019/04/image-beb0bc78.png)


### 问题

1. 页面访问登陆后报/graphql 500问题

cd /usr/local/apache-skywalking-apm-incubating/logs
#查看skywalking-oap-server.log有无错误信息，即skywalking应用启动日志信息
#查看oap.log有无错误信息，即确认es连接成功[或者改成使用h2数据库以确认是否报500，以定位es配置或连接问题]


### 激活Agent模块

```
vim /usr/local/apache-skywalking-apm-incubating/agent/config/agent.config  #修改配置如下
```
![image.png](https://img.hacpai.com/file/2019/04/image-84e44dae.png)
![image.png](https://img.hacpai.com/file/2019/04/image-395d4fab.png)

启动agent应用

(1)SpringMVC（tomcat）

编辑tomcat的bin目录下setenv.sh脚本，添加命令
`JAVA_OPTS="$JAVA_OPTS -javaagent:/usr/local/apache-skywalking-apm-incubating/agent/skywalking-agent.jar"`  
`/usr/local/skywalking-agent/skywalking-agent.jar`  实际情况根据skywalking-agent.jar所在绝对路径进行配置

(2)Springboot

启动命令：java -javaagent:/usr/local/apache-skywalking-apm-incubating/agent/skywalking-agent.jar -jar myApplication.jar

实际情况根据skywalking-agent.jar所在绝对路径执行命令