title: CentOS系统操作之备查
date: '2019-05-19 10:44:57'
updated: '2019-05-19 10:44:57'
tags: [CentOS]
permalink: /articles/2019/05/19/1558233897353.html
---
![](https://img.hacpai.com/bing/20190401.jpg?imageView2/1/w/768/h/432/interlace/1/q/100)
<br />
<br />
<br />
&nbsp;&nbsp;&nbsp;&nbsp;本文主要介绍自己在使用CentOS时，针对一些常用场景所使用的命令组合以及些许小技巧，仅供直接快速备查之需要！

### 系统
```
    uname -a                   #系统信息
    cat /etc/redhat-release    #操作系统版本号

    uptime                     #系统运行时间，用户数，负载情况
    w                          #查看活跃用户
    last                       #用户登录日志

    chkconfig --list           #系统服务状态  

    reboot now #系统重启
```

### 环境变量
```
    env                        #系统环境变量

    vim /etc/profile
    vim ~/.bash_profile
```

### CPU
#### 1、cpu
```
    cat /proc/cpuinfo          #CPU信息
```
#### 2、top命令
``` 
    top
    #按e将使用内存单位依次切换m,g……
    #按M则根据内存使用大小排序

    top -Hp 31559 -d 1 -n 1 #查看PID=31559的进程下各个线程的资源消耗情况
    top -H -p 7923 #显示某个进程7923相关资源

    echo 3 > /proc/sys/vm/drop_caches  #清除无效占用的buff/cache内存
```

### 内存
```
    free -m                    #系统内存及交换分区使用情况
```

### 磁盘
#### 1、磁盘挂载
```
    #单次挂载磁盘，机器reboot之后将失效并需要重新挂载
    mount /dev/vdb1 /opt 

    #永久挂载
    vim /etc/fstab  #添加如下
    /dev/vdb1 /opt ext4 defaults 1 1
```

#### 2、空间查看
```
    df -h                      #各分区使用情况
    df -hl        #查看磁盘使用情况以及剩余情况等

    du -sh *      #显示当前目录下各文件及文件夹大小
    du -sh * | sort -nr    #显示大小并按照大小倒序
    du jdk-8u181-linux-x64.tar.gz -h #查看文件或文件夹占用空间大小
```

### 用户
#### 1、创建用户组aokay及用户zorke
```
    groupadd aokay   #用户组aokay  
    cd / && chgrp -R aokay /opt/ #为用户组aokay分配根目录opt
    chmod 777 opt    #为用户组根目录opt设权限
    mkdir -m 775 /opt/app && chgrp -R aokay /opt/  #为用户组所有用户分配公共应用目录app

    useradd -g aokay -d /opt/zorke zorke  #为用户组aokay添加用户zorke
    passwd zorke  #为用户zorke设置密码
    #chmod 755 /etc/sudoers  #【当前操作用户为root用户下无需此操作】
    echo "devops ALL=(ALL:ALL) NOPASSWD: ALL" >> /etc/sudoers #添加管理员权限
    #chmod 440 /etc/sudoers  #【当前操作用户为root用户下无需此操作】
 
    su zorke
    cd ~
```
#### 2、为用户aokay:zorke分配某个目录权限
```
    su #root
    chown -R aokay:zorke /app
    exit
```

### 定时任务

#### 1、为zorke用户添加crontab权限
```
    su
    crontab -u zorke
    exit
```
#### 2、zorke用户设置定时任务
```
    crontab -e
    10,20,30,40,50 0-23 * * * /bin/bash /app/zorke/scripts-task.sh
    service crond restart  #service crond status
    crontab -l #查看定时任务列表
```
#### 3、直接root用户设置定时任务

&nbsp;&nbsp;&nbsp;&nbsp;crontab root用户执行定时任务 - 可能会因相关文件执行权限及访问权限导致相关权限问题，推荐使用1 + 2的设置特定用户zorke执行定时任务
```
    su #root用户
    cd /etc/cron.d
    vim task1crontab.cron #添加如下一条
    10,20,30,40,50 0-23 * * * /bin/bash /app/zorke/scripts-task.sh
    crontab task1crontab.cron   #添加定时任务
    crontab -l #查看定时任务 
    exit 
```

### 防火墙
&nbsp;&nbsp;&nbsp;&nbsp;以CentOS7.4默认防火墙firewalld（推荐使用）的开启、使用、关闭，以及firewalld与iptables两个防火墙之间的切换、使用、二者端口开启的操作等为例！
#### 1、firewalld VS iptables
```
(a)、无 -> firewalld

    systemctl status firewalld    #查看firewalld防火墙状态
    systemctl start firewalld     #打开firewalld防火墙
    systemctl stop firewalld      #关闭firewalld防火墙
    systemctl restart firewalld   #重启firewalld防火墙

    firewall-cmd --permanent --zone=public --add-port=8800/tcp #开放端口
    firewall-cmd --reload         #刷新防火墙，开放的端口生效
    firewall-cmd --zone=public --query-port=8800/tcp #检查端口是否生效

(b)、firewalld -> iptables

    systemctl stop firewalld   #停用firewalld
    systemctl mask firewalld   #mask firewalld

    yum install -y iptables        #安装iptables
    yum install iptables-services  #安装iptables-services

    vim /etc/sysconfig/iptables  #修改iptables文件，添加如：
    -A INPUT -p tcp --dport 8800 -j ACCEPT  #即开放端口8800
    service iptables restart   #重启iptables防火墙，开放的端口生效

(c)、iptables -> firewalld

    systemctl stop iptables.service #停止iptables防火墙服务
    systemctl unmask firewalld.service #unmask firewalld
    systemctl start firewalld     #打开firewalld防火墙

(d)、firewalld关闭端口

    firewall-cmd --remove-port=9091/tcp --permanent
    firewall-cmd --reload
```
#### 2、端口管理
firewalld
```
    firewall-cmd --list-ports #查看已开放端口
    firewall-cmd --zone=public --add-port=80/tcp --permanent #开启80端口
    firewall-cmd --reload #重启防火墙以使得开启的80端口生效
    firewall-cmd --zone= public--remove-port=80/tcp --permanent #删除80端口配置
    
    netstat -lntp #查看监听的端口
    netstat -lnp | grep 8080 #查看8080端口被哪个进程占用
```

### 网络
```
    curl ifconfig.me #查看本机外网ip地址

    netstat -ano #查看系统上的tcp连接数
```

### 其他
```
    rpm -qa                    #已安装软件包
```

### 来源
- [CentOS 系统管理](https://www.zorkelvll.cn/blogs/zorkelvll/articles/2018/11/08/1541688065445)
- [CentOS7.4 环境防火墙及端口管理](https://www.zorkelvll.cn/blogs/zorkelvll/articles/2018/11/15/1542211485122)
- [CentOS7.2 各类环境变量配置](https://www.zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541171981714)
- [CentOS 命令](https://www.zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541172085663)

<br />
<br />
<br />