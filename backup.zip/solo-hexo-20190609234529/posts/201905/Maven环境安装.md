title: Maven环境安装
date: '2019-05-19 11:44:34'
updated: '2019-05-19 11:44:34'
tags: [Maven]
permalink: /articles/2019/05/19/1558237474345.html
---
![](https://img.hacpai.com/bing/20181010.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/12/1542037329714](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/12/1542037329714)

### 背景
&nbsp;&nbsp;本文主要简单地介绍maven环境的安装以及环境变量的配置，本身安装就非常简单，此处仅做记录！！

1、下载并解压

    wget http://mirrors.tuna.tsinghua.edu.cn/apache/maven/maven-3/3.6.0/binaries/apache-maven-3.6.0-bin.tar.gz
    tar -zxvf apache-maven-3.6.0-bin.tar.gz

2、配置环境变量

    vim /etc/profile 
    export M2_HOME=/root/app/apache-maven-3.6.0 
    export PATH=$PATH:$M2_HOME/bin