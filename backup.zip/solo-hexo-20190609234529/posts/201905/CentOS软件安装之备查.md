title: CentOS软件安装之备查
date: '2019-05-19 10:05:51'
updated: '2019-05-19 10:06:13'
tags: [CentOS]
permalink: /articles/2019/05/19/1558231551071.html
---
![](https://img.hacpai.com/bing/20190226.jpg?imageView2/1/w/768/h/432/interlace/1/q/100)
<br />
<br />
<br />
&nbsp;&nbsp;&nbsp;&nbsp;本文主要介绍自己在使用CentOS时，针对一些软件环境的安装以及配置使用等，集中在此以作备查！
### git
```
    yum install git #安装git 
```

### nvm
``` 
    #通过wget安装nvm，重新打开shell窗口即可使用nvm
    wget -qO- https://raw.githubusercontent.com/creationix/nvm/v0.33.11/install.sh | bash 

    #或者，通过curl安装nvm，重新打开shell窗口即可使用nvm
    curl -o- https://raw.githubusercontent.com/creationix/nvm/v0.33.11/install.sh | bashcommand -v nvm 
```
或者：见   [NVM 管理 NodeJS 版本](https://www.zorkelvll.cn/blogs/zorkelvll/articles/2018/11/22/1542901045294)

### java
```
    vim /etc/profile 
    #jvm-jdk
    JAVA_HOME="/usr/local/jvm/jdk1.8.0_181"
    JRE_HOME=${JAVA_HOME}/jre
    CLASS_PATH=".:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar"
    PATH=".$PATH:$JAVA_HOME/bin"
    export JAVA_HOME JRE_HOME CLASS_PATH PATH
```
### maven
```
    vim /etc/profile 
    export M2_HOME=${HOME}/app/apache-maven-3.5.4
    export PATH=$PATH:$M2_HOME/bin
```
### golang
```
    vim /etc/profile 
    export GOROOT=${HOME}/go1.11.1 
    export GOPATH=${HOME}/gopath 
    export GOBIN=${GOPATH}/bin 
    export PATH=${PATH}:${GOBIN}:${GOROOT}/bin
    #其中 gopath 下建目录 pkg,bin,src
```

<br />
<br />
<br />