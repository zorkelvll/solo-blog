title: MySQL环境安装
date: '2019-05-19 11:52:41'
updated: '2019-05-19 11:52:41'
tags: [MySQL]
permalink: /articles/2019/05/19/1558237961809.html
---
![](https://img.hacpai.com/bing/20180603.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541171868657](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541171868657)

### 背景
&nbsp;&nbsp;&nbsp;&nbsp;本文介绍在Linux-CentOS7.2系统环境中安装MySQL5.7,同时也给出了MySQL的卸载步骤，以及设置防火墙、开放3306端口、允许远程访问等

**一、卸载MySQL**

&nbsp;&nbsp;&nbsp;&nbsp;首先介绍MySQL的卸载，用以解决已经安装错误或者防止重装等问题：

1、yum方式

    yum list installed mysql*  #查看yum是否安装过mysql
    yum remove mysql-community-client  #根据前面命令返回的列表中的名字进行卸载
    rm -rf /var/lib/mysql  #删除文件
    rm /etc/my.cnf   #删除配置文件

2、rpm方式

    rpm -qa | grep -i mysql    #rpm查看安装
    rpm -e mysql57-community-release-el7-9.noarch #根据前面命令返回的列表中的名字进行卸载
    cd /var/lib/ & rm -rf mysql/  #删除文件夹


3.1 清除余项

    whereis mysql  #查询余项
    rm -rf /usr/bin/mysql  #根据上面命令返回的结果进行删除

3.2 删除配置

    rm –rf /usr/my.cnf
    rm -rf /root/.mysql_sercret

3.3 检查剩余配置

    chkconfig --list | grep -i mysql
    chkconfig --del mysqld


**二、YUM方式安装MySQL**

1、卸载MariaDB

    rpm -qa | grep mariadb   #查询mariadb
    rpm -e --nodeps mariadb-libs-5.5.47-1.el7_2.x86_64   #根据前面命令查询结果卸载

2、关闭selinux
  
    vim /etc/selinux/config  
    #把SELINUX=enforcing改为SELINUX=disabled后存盘退出重启机器；该项用以解决启动MySQL service服务报错：ERROR!The server quit without updating PID file

3、安装MySQL

    #yum list | grep mysql
    rpm -Uvh http://dev.mysql.com/get/mysql57-community-release-el7-7.noarch.rpm
    yum install mysql-community-server
    service mysqld start #启动服务
    cat /var/log/mysqld.log #或者使用vim查找，命令找到A temporary password is generated for root@localhost: qW/&5(2v7Q%g  读取root初始密码   qW/&5(2v7Q%g

4、更改密码

    mysql -uroot -p   #输入密码qW/&5(2v7Q%g
    SQL>set global validate_password_policy=0;
    SQL>set global validate_password_length=4;
    SQL>ALTER USER USER() IDENTIFIED BY 'root123';

5、重启mysql并开启远程访问

    service start mysqld  #【service restart mysqld】
    mysql -uroot -p  #使用新密码登录即可
    SQL>GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY 'root123' WITH GRANT OPTION;    #开启远程访问
    firewall-cmd --zone=public --add-port=3306/tcp --permanent  #开放3306端口
    firewall-cmd --reload #刷新防火墙端口
    #systemctl restart firewalld.service  #重启防火墙服务


**三、其他命令**

**0、彻底卸载mysql：**

    rpm -qa|grep mysql
    yum remove ******
    rm -rf /var/lib/mysql
    rm /etc/my.cnf

**1、设置防火墙**

&nbsp;&nbsp;远程访问 MySQL，需要开放 3306 端口：

    firewall-cmd --permanent --zone=public --add-port=3306/tcp
    firewall-cmd --permanent --zone=public --add-port=3306/udp
    firewall-cmd --reload


&nbsp;&nbsp;如果是 CentOS 7，需要将 MySQL 服务加入防火墙，然后重启防火墙：

    firewall-cmd --zone=public --permanent --add-service=mysql
    systemctl restart firewalld


**2、设置允许远程访问**

&nbsp;&nbsp;默认情况下 MySQL 是不允许远程连接的，所以在 Java 项目或者 MySQLWorkbench 等数据库连接工具连接服务器上的 MySQL 服务的时候会报 "Host 'x.x.x.x' is not allowed to connect to this MySQL server"。可以通过下面的设置解决。详细可以参考之前写的一篇文章 _[XXX is not allowed to connect to this MySQL server](https://blog.csdn.net/u011886447/article/details/78462787)。_
    
    ① grant all privileges on *.* to root@"%" identified by '0';
    ② flush privileges;

\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-

**提示：**

&nbsp;&nbsp;在执行第一条命令的时候，可能会报：

'ERROR 1820 (HY000): You must reset your password using ALTER USER statement before executing this statement.' 需要让我们重置密码。原因是因为我刚刚的命令中设置的数据库密码是0，这个密码过于简单，不符合 MySQL 的安全要求。只要重新设置一个复杂点的密码就可以了：

    mysql> SET PASSWORD = PASSWORD('xxx');   //xxx 是重置的新的复杂的密码

\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-

**思考**：

之前设置简单密码是没有问题的，可能原因：

① 可能目前环境是 CentOS 7 + MySQL 5.7.21，安全性有所提升。

② 也有可能是之前的数据库设置过

    mysql> set global validate\_password\_policy=0;
    mysql> set global validate\_password\_length=1;

允许设置简单密码

**3、相关命令**

**MySQL 相关：**

    systemctl start mysqld    #启动mysql
    systemctl stop mysqld    #停止mysqld
    systemctl restart mysqld    #重启mysqld
    systemctl enable mysqld    #设置开机启动
    systemctl status mysqld    #查看 MySQL Server 状态