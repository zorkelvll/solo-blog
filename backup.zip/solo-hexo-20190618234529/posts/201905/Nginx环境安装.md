title: Nginx环境安装
date: '2019-05-19 11:52:19'
updated: '2019-05-19 11:52:19'
tags: [Nginx]
permalink: /articles/2019/05/19/1558237939269.html
---
![](https://img.hacpai.com/bing/20171128.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541171920974](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541171920974)

### 背景
&nbsp;&nbsp;&nbsp;&nbsp;本文介绍在Linux-CentOS系统环境中安装Nginx1.14.0,同时也将在后续的过程中不断维护和给出nginx.conf配置管理，以及yum安装nginx和配置！

**一、源码安装运行Nginx**

1、下载&解压：

    cd ~/app
    wget https://nginx.org/download/nginx-1.14.0.tar.gz
    tar -zxvf nginx-1.14.0.tar.gz

2、编译

    yum install gcc-c++ openssl openssl-devel
    yum install -y pcre pcre-deve zlib zlib-devel --setopt=protected_multilib=false
    
    cd nginx-1.14.0/
    ./configure
    make
    make install
    
    whereis nginx

3、运行

    /usr/local/nginx/sbin/nginx  #启动nginx
    
    /usr/local/nginx/sbin/nginx -s reload #平滑重启nginx
    /usr/local/nginx/sbin/nginx -s stop   #停止nginx，相当于先查出nginx进程id再使用kill命令强制杀掉进程
    /usr/local/nginx/sbin/nginx -s quit   #从容停止nginx，停止步骤是待nginx进程处理任务完毕进行停止
    
    #推荐先停止再启动，即nginx -s quit  &  nginx
    #重新加载配置文件，想让它立即生效时， nginx -s reload 

4、开启自启nginx

    vim /etc/rc.local
    #增加一行： /usr/local/nginx/sbin/nginx

**二、yum方式安装nginx**

    yum -y install nginx
    #配置文件所在目录 vim /etc/nginx/nginx.conf

**三、nginx配置文件/usr/local/nginx/conf/nginx.conf**

    nginx -t #检测配置文件是否有错误


**四、MacOS下安装Nginx**

    brew install nginx  #安装nginx
    brew services start nginx #启动nginx


TODO 待后续补充和继续完善