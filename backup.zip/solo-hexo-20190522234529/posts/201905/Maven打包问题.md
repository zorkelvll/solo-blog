title: Maven打包问题
date: '2019-05-19 11:40:38'
updated: '2019-05-19 11:40:38'
tags: [Maven]
permalink: /articles/2019/05/19/1558237238667.html
---
![](https://img.hacpai.com/bing/20171205.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/15/1542213532257](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/15/1542213532257)

### 背景

&nbsp;&nbsp;本文主要是记录在使用maven进行打包的过程中所遇到的一些问题以及相应的解决方案！


二、
1、springboot多模块项目maven依赖打包失败问题

分析：被引入模块pom.xml文件中不应该有spring-boot-maven-plugin插件

原因：被引入模块的这个插件的 repackage 目标会处理该模块的 jar 包，导致依赖它的模块无法使用它

参考：https://my.oschina.net/tridays/blog/825245

一、

**问题5**

&nbsp;&nbsp;&nbsp;&nbsp;Mac下在intellij idea命令行中执行mvn deploy执行报错Pemission denied，如maven-install-plugin:2.4:install (default-install) Permission denied，

&nbsp;&nbsp;&nbsp;&nbsp;可以将当前工程目录下的隐藏目录中的~文件夹删除，重新执行mvn deploy命令即可（前提是在4中为maven命令mvn添加了执行权限）

  

**问题4**

&nbsp;&nbsp;&nbsp;&nbsp;Mac下在intellij idea命令行中执行mvn clean无法执行或者权限不够必须添加sudo才可以执行，解决此问题如

&nbsp;&nbsp;&nbsp;&nbsp;chmod a+x /usr/local/apache-maven-3.5.3/bin/mvn    (a:所有用户 +:增加权限 x:执行权限)

  

**问题3**

&nbsp;&nbsp;&nbsp;&nbsp;maven-nexus在设置Public Repositories的时候，需要注意，各个Ordered Group Repositories的下各仓库的顺序，这个顺序是maven在私服中查找的顺序

&nbsp;&nbsp;&nbsp;&nbsp;此外，maven在pom文件中配置各个、、 的时候，发布的所在机器如开发人员本地的maven的settings.xml中的需要配置对象仓库的id及用户名、密码


**问题2**

&nbsp;&nbsp;&nbsp;&nbsp;解决maven私服无法下载json-lib的问题：

        <dependency>
            <groupId>net.sf.json-lib</groupId>
            <artifactId>json-lib</artifactId>
            <version>2.4</version>
            <!--解决maven无法下载json-lib的问题-->
            <classifier>jdk15</classifier>
        </dependency>



**问题1**

&nbsp;&nbsp;&nbsp;&nbsp;解决mvn compile时报“程序包TF-8

            <plugin>
                <artifactId>maven-compiler-plugin</artifactId>
                <configuration>
                    <source>${java.version}</source>
                    <target>${java.version}</target>
                    <encoding>UTF-8</encoding>
                    <!--解决：程序包com.sun.tools.internal.xjc.reader.xmlschema.bindinfo等等jdk自带的jar包不存在  问题-->
                    <compilerArguments>
                        <bootclasspath>${JAVA_HOME}/lib/tools.jar:${JAVA_HOME}/jre/lib/rt.jar:${JAVA_HOME}/jre/lib/jce.jar</bootclasspath>
                    </compilerArguments>
                </configuration>
            </plugin>