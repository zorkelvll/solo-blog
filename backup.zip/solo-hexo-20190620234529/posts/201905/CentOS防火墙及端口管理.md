title: CentOS防火墙及端口管理
date: '2019-05-19 11:41:30'
updated: '2019-05-19 11:41:30'
tags: [CentOS]
permalink: /articles/2019/05/19/1558237290192.html
---
![](https://img.hacpai.com/bing/20180827.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/15/1542211485122](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/15/1542211485122)

### 背景
&nbsp;&nbsp;本文主要是介绍CentOS7.2的默认防火墙firewalld的开启、使用、关闭，以及firewalld防火墙与iptables防火墙两个之间的切换和使用，以及各自端口开启的操作等！

一、无 -> firewalld

    systemctl status firewalld    #查看firewalld防火墙状态
    systemctl start firewalld     #打开firewalld防火墙
    systemctl stop firewalld      #关闭firewalld防火墙
    systemctl restart firewalld   #重启firewalld防火墙

    firewall-cmd --permanent --zone=public --add-port=8800/tcp #开放端口
    firewall-cmd --reload         #刷新防火墙，开放的端口生效
    firewall-cmd --zone=public --query-port=8800/tcp #检查端口是否生效

二、firewalld -> iptables

    systemctl stop firewalld   #停用firewalld
    systemctl mask firewalld   #mask firewalld

    yum install -y iptables        #安装iptables
    yum install iptables-services  #安装iptables-services

    vim /etc/sysconfig/iptables  #修改iptables文件，添加如：
    -A INPUT -p tcp --dport 8800 -j ACCEPT  #即开放端口8800
    service iptables restart   #重启iptables防火墙，开放的端口生效

三、iptables -> firewalld

    systemctl stop iptables.service #停止iptables防火墙服务
    systemctl unmask firewalld.service #unmask firewalld
    systemctl start firewalld     #打开firewalld防火墙

四、firewalld关闭端口

    firewall-cmd --remove-port=9091/tcp --permanent
    firewall-cmd --reload