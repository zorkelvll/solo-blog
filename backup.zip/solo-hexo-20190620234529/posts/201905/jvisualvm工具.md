title: jvisualvm工具
date: '2019-05-19 11:12:29'
updated: '2019-05-19 11:12:29'
tags: [Java]
permalink: /articles/2019/05/19/1558235549534.html
---
![](https://img.hacpai.com/bing/20190112.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

<br />
<br />
<br />
### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2019/01/16/1547616944492](https://zorkelvll.cn/blogs/zorkelvll/articles/2019/01/16/1547616944492)

### 背景

&nbsp;&nbsp;&nbsp;&nbsp;本文主要是介绍jvisualvm工具的开启以及远程使用！


1、在服务器上设置jmx参数

    vim /etc/profile
    #添加
    export JAVA_OPTS='-Djava.rmi.server.hostname=192.250.110.153 -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=1099 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false'

2、在服务器上jar包启动开启jmx远程连接

    nohup java $JAVA_OPTS -jar sp-provider-1.0.0-SNAPSHOT.jar >/dev/null

3、在本地命令jvisualvm打开可视化窗口

远程 -> 添加远程主机 -> 在所添加的远程主机上”添加JMX连接“ -> 添加地址以及对应端口1099打开即可

4、例如开启OOM-dump

    nohup java -jar -Djava.rmi.server.hostname=192.250.110.153 -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=1099 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -XX:+HeapDumpOnOutOfMemoryError sp-provider-1.0.0-SNAPSHOT.jar -XX:HeapDumpPath=~/dumps/ >/dev/null &

<br />
<br />
<br />