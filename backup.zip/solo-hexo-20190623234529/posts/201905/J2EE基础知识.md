title: J2EE基础知识
date: '2019-05-19 11:24:39'
updated: '2019-05-19 11:24:39'
tags: [Java]
permalink: /articles/2019/05/19/1558236279653.html
---
![](https://img.hacpai.com/bing/20180824.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/12/08/1544280958346](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/12/08/1544280958346)

### 背景
&nbsp;&nbsp;&nbsp;&nbsp;本文主要是记录在学习J2EE过程中的一些知识点备忘！

20190414

**J2EE**：sun公司提出的多层、分布式、基于组件的企业级应用模型  
**层次**：客户层组件、web层组件、business层组件、企业信息系统层（EIS)  
**简记**：J2EE=Components（规范-Servlet/jsp/ejb/jsf）+Container（容器-Web容器/EJB容器/Spring容器）+MVC模式+Service服务+多层次

20181213

1、JSP工作原理

JSP是一种Servlet，且不同于HttpServlet；

HttpServlet是先由源代码编译为class文件后，在部署到服务器下，是先编译后部署，而JSP则是先部署后编译；

JSP会在客户端第一次请求JSP文件时被编译为HttpJspPage类（接口Servlet的一个子类），该类会被服务器临时存放在服务器工作目录里面！

2、JSP内置对象及其作用

* request：封装客户端的请求，包含来自GET/POST请求的参数
* response：封装服务器对客户端的响应
* pageContext：通过该对象可以获取其他对象
* session：封装用户会话的对象
* application：封装服务器运行环境的对象
* out：输出服务器响应的输出流对象
* config：Web应用的配置对象
* page：JSP页面本身
* exception：封装页面抛出异常的对象

3、Request对象的方法

* setAttribute：设置名为name的request的参数值
* getAttribute：返回由name指定的属性值
* getAttributeNames：返回request对象所有属性的名字集合，结果是一个枚举的实例
* getCookies：返回客户端的所有Cookie对象，结果是一个Cookie数组
* getCharacterEncoding：返回请求中的字符编码方式 
* getContentLength：返回请求的Body的长度
* getHeader：获得HTTP协议定义的文件头信息
* getHeaders：返回指定名字的request Header的所有值，结果是一个枚举的实例
* getHeaderNames：返回所有request Header的名词，结果是一个枚举ed实例
* getInputStream：返回请求的输入流，用于获得请求中的数据
* getMethod：获得客户端向服务器端传送数据的方法
* getParameter：获得客户端传送给服务器端的由name指定的参数值
* getParameterNames：获得客户端传送给服务器端的所有参数的名字，结果是一个枚举的实例
* getParameterValues：获得由name指定的参数的所有值
* getProtocol：获得客户端像服务器端传送数据所依据的协议名称
* getQueryString：获得查询字符串
* getRequestURI:获得发出请求字符串的客户端地址
* getRemoteAddr：获得客户端的IP地址
* getRemoteHost：获得客户端的名字
* getSession：返回和请求相关Session
* getServerName：获取服务器的名字
* getServletPath：获取客户端所请求的脚本文件的路径
* getServerPort：获取服务器的端口号
* removeAttribute：删除请求中的一个属性

4、request.getAttribute()  VS  request.getParameter()

从获取方向来看：getAttribute获取对象容器中的数据值，getParameter获取POST/GET传递的参数值

从用途来看：

* getAttribute：用于服务器端重定向时，即在servlet中使用forward函数或struts中使用mapping.findForward,只能受到程序用setAttribute传过来的值
* getParameter：用于客户端重定向，即点击了链接或提交按钮时传值用，用于在利用表单或者url重定向传值时接收数据使用
* getAttribute可以接收setAttribute设置的对象，而getParameter只能传字符串；setAttribute是应用服务器把这个对象放在该页面所对应的一块内存中去，当页面服务器重定向另一个页面时，应用服务器会吧这块内存拷贝到另一个页面所对应的内存中，session也一样仅仅区别在于对象在内存中的生命周期不一样；getParameter是应用服务器分析request页面的文本时，取得设在表单或url重定向时的值


5、include指令  VS  include行为

* include指令：JSP可以通过include指令来包含其他文件，被包含的文件可以是JSP文件、HTML或文本文件，会随着JSP本身一起呗同时编译执行，语法格式如下： <%@ include file="文件相对 url 地址" %>

* include动作：jsp:include动作元素用来包含静态和动态的文件。该动作把指定文件插入正在生成的页面。语法格式如下： jsp:include page="相对 URL 地址" flush="true"
    

6、JSP四种作用域

* page：表示与一个页面相关的对象和属性
* request：表示与web客户机发出的一个请求相关的对象和属性，一个请求如果跨域多个页面涉及多个web组件，则可以将需要在页面显示的临时数据置于此作用域
* session：代表某个用户与服务器建立的一次会话相关的对象和属性
* application：代表与整个web应用相关对象和属相，是一个全局作用域

7、如何实现JSP  OR  Servlet的单线程模式

* JSP：通过page指令设置，<%@page isThreadSafe=”false”%>
* Servlet：自定义Servlet实现SingleThreadModel接口

=>单线程工作模式，会导致每个请求创建一个Servlet实例！

8、实现会话跟踪的技术

* 使用Cookie
* URL重写
* 隐藏的表单域
* HttpSession

9、Cookie  VS  Session

Session是在服务端保存的一个数据结构，用来跟踪用户的状态，这个数据可以保存在集群、数据库、文件中；

Cookie是客户端保存用户信息的一种机制，用来记录用户的一些信息，也是实现Session的一种方式



20181209

1、Forward转发  VS  Redirect重定向

* Forward是服务器行为，Redirect是客户端行为
* Forward：通过RequestDispatcher对象的forward(HttpServletRequest req,HttpServletResponse res)方法实现的，RequestDispatcher可以通过HttpServletRequest的getRequestDispatcher()方法获得
* Redirect：利用服务器返回的状态码来实现的；客户端浏览器请求服务器的时候，服务器会返回一个状态码，服务器通过HttpServletRequestResponse的setStatus(int status)方法设置状态码；如果服务器返回301或者302，则浏览器会到新的网址重新请求该资源
* （1）从地址栏显示：forward是服务器请求资源，服务器直接访问目标地址的URL，把那个URL的响应内容读取过来，然后把这些内容发送给浏览器，浏览器根本不知道服务器发送的内容来自于哪里，地址栏还是原来的地址的；而redirect则是服务端根据逻辑，发送一个状态码，告诉浏览器重新去请求那个地址，地址栏显示的是新的URL
* （2）从数据共享：forward是转发页面和转发到的页面可以共享request里面的数据；而redirect不能共享数据
* （3）从运用地方：forward一般用于用户登录的时候，根据角色转发到相应的模块；redirect一般用于用户注销登录时返回主页面或跳转到其他的网站等
* （4）从效率上：forward高，redirect低

2、Refresh刷新

自动刷新不仅可以实现一段时间之后自动跳转到另一个页面，也还可以实现一段时间之后自动刷新本页面。Servlet中通过HttpServletResponse对象设置Header属性实现自动刷新。

3、Servlet & 线程安全

Servlet不是线程安全的，多线程并发的读写会导致数据不同步的问题。=>解决办法：尽量不要定义name属性，而是要把name变量分别定义在doGet和doPost方法内；使用synchronized(name){}语句块可以解决问题，但是会造成线程的等待！注意：多线程并发的读写Servlet类属性会导致数据不同步，但是如果只是并发地读取属性而不写入，则不存在数据不同步的问题，因此Servlet中的只读属性是定义为final类型的

4、JSP  &  Servlet

Servlet是一种特殊的Java程序，运行于服务器的JVM中，能够依靠服务器的支持向浏览器提供显示内容；JSP本质上是Servlet的一种简易形式，会被服务器处理成一个类似于Servlet的Java程序，可以简化页面内容的生成！

二者的区别在于，Servlet的应用逻辑是在Java文件中的并且完全从表示层中的HTML分离开来，而JSP则是Java和HTML组合成一个扩展名为jsp的文件（可以粗浅地认为：Servlet是在java中写HTML，JSP是在HTML中写Java代码）！JSP侧重于视图，Servlet更侧重于控制逻辑！在MVC架构模式中，JSP适合充当视图view，而Servlet适合充当控制器controller




20181208

1、Servlet

&nbsp;&nbsp;&nbsp;&nbsp;JavaWeb中，Servlet主要负责接收用户请求HttpServletRequest，在doGet(),doPost()中做相应的处理，并将回应HttpServletResponse反馈给用户。Servlet可以设置初始化参数，供Servlet内部使用，一个Servlet类只会有一个实例，在它初始化时调用init()方法，销毁时调用destroy()方法。Servlet需要在web.xml中配置，一个Servlet可以设置多个URL访问，Servlet不是线程安全的（使用类变量需要谨慎）

2、Servlet  VS  CGI

（1）CGI缺点：

* 需要为每个请求启动一个操作CGI程序的系统进程，如果请求频繁则会带来很大的开销
* 需要为每个请求加载和运行一个CGI程序，开销也很大
* 需要重复编写处理网络协议的代码及编码，这些工作非常耗时

（2）Servlet优点：

* 只需要启动一个操作系统进程以及加载一个JVM，大大降低了系统开销
* 如果多个请求需要做同样处理的时候，此时只需架子啊一个类，大大降低开销
* 所有动态加载的类可以实现对网络协议以及请求解码的共享，大大降低了工作量
* Servlet能直接与wbe服务器交互，而普通的CGI程序不能；Servlet也可以在各个程序之间共享数据，使得数据库连接池之类的功能很容易实现

（3）补充：Servlet技术是Sun公司于1996年发布与CGI进行竞争的，是一个特殊的java程序，一个基于java的web应用，通常包含一个或多个Servlet类，Servlet不能够自行创建并执行，必须是在Servlet容器中运行的，容器将用户的请求传递给Servlet程序并将Servlet的响应回传给用户。通常一个Servlet会关联一个或多个JSP页面，以前CGI经常因为性能开销上的问题被诟病，其实Fast CGI早就已经解决了CGI效率上的问题，所以也不要心口开销地诟病CGI，事实上很多熟悉的网站都使用了CGI技术

3、Servlet方法  &&  Servlet生命周期

（1）Servlet接口中定义了5个方法，且前3个与其生命周期相关：

* void init(ServletConfig config) throws ServletException
* void service(ServletRequest req,ServletResponse resp) throw ServletException,java.io.IOException
* void destory()
* java.lang.String getServletInfo()
* ServletConfig getServletConfig()

(2)生命周期：web容器加载Servlet并将其实例化后，Servlet生命周期开始，容器运行其init()方法进行Servlet的初始化；请求到达时调用Servlet的service()方法，service()方法会根据需要调用与请求对应doGet()或doPost()等方法；当服务器关闭或项目被卸载时服务器会将Servlet销毁，此时会调用Servlet的destroy()方法。init和destroy方法只会执行一次，service方法客户端每次请求Servlet都会执行。

4、get请求  VS  post请求

* get请求用来从服务器上获得资源，而post请求用来向服务器提交数据，GET方式提交表单的典型应用是搜索引擎。GET方式就是被设计为查询用的。
* get请求将表单中数据按照name=value形式添加到action所指向的URL后面，并且URL与数据之间使用？连接，而数据中的各个变量使用&连接；post则是将表单中的数据放在HTTP协议的请求头或消息体中，传递到action所指向URL
* get请求传输的数据会受到URL长度限制(1024字节即256个字符)，而post则可以传输大量的数据，如上传文件通常需要使用post请求
* get请求时参数会显示在地址栏上，因此敏感数据最好还是使用post
* get请求使用MIME类型application/x-www-form-urlencoded的URL编码（也叫百分号编码）文本的格式传递参数，保证被传送的参数由遵循规范的文本组成
* Form标签中method的属性是get时调用doGet()，为post时调用doPost()



说明：本JavaGuide系列博客为来源于[https://github.com/Snailclimb/JavaGuide](https://github.com/Snailclimb/JavaGuide)
等学习网站或项目中的知识点，均为自己手打键盘系列且内容会根据继续学习情况而不断地调整和完善！