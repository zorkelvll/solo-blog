title: NVM管理NodeJS版本
date: '2019-05-19 11:26:20'
updated: '2019-05-19 11:26:20'
tags: [JS]
permalink: /articles/2019/05/19/1558236380064.html
---
![](https://img.hacpai.com/bing/20180522.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/22/1542901045294](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/22/1542901045294)

### 背景
&nbsp;&nbsp;本文主要是介绍在MacOS或CentOS下NVM工具的安装，以及使用nvm管理安装不同版本的nodejs的方法！

一、NVM安装

    cd ~/ && git clone https://github.com/creationix/nvm.git .nvm #下载源码
    cd ~/.nvm && git checkout v0.33.11 #切换git分支版本
    sudo sh ./nvm.sh #安装nvm

    vim ~/.bash_profile #添加如下环境变量
    export NVM_DIR="$HOME/.nvm"
    [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
    [ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"  # This loads nvm bash_completion    

    source ~/.bash_profile
    #安装完成后，关闭终端，重新打开终端 输入nvm验证是否安装成功

不同版本号的NVM，详见[https://github.com/creationix/nvm/blob/master/README.md](https://github.com/creationix/nvm/blob/master/README.md)

二、NVM命令

*   `nvm install stable` ## 安装最新稳定版 node
    
*   `nvm install ` ## 安装指定版本，可模糊安装，如：安装v4.4.0，既可nvm install v4.4.0，又可nvm install 4.4
    
*   `nvm uninstall ` ## 删除已安装的指定版本，语法与install类似
    
*   `nvm use ` ## 切换使用指定的版本node
    
*   `nvm ls` ## 列出所有安装的版本
    
*   `nvm ls-remote` ## 列出所有远程服务器的版本（官方node version list）
    
*   `nvm current` ## 显示当前的版本
    
*   `nvm alias  ` ## 给不同的版本号添加别名
    
*   `nvm unalias ` ## 删除已定义的别名
    
*   `nvm reinstall-packages ` ## 在当前版本 node 环境下，重新全局安装指定版本号的 npm 包