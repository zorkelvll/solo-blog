title: Mac使用小技巧
date: '2019-05-19 11:45:46'
updated: '2019-05-19 11:45:46'
tags: [Mac]
permalink: /articles/2019/05/19/1558237546229.html
---
![](https://img.hacpai.com/bing/20180311.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/10/1541833672635](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/10/1541833672635)

1、打开“前往文件夹”：shift+command+g

2、为root用户设置密码
    
    sudo su  #然后输入当前登录用户的密码
    #进入到sh-3.2#的命令窗口界面
    passwd root  #执行设置root密码命令操作
    #分别输入两次相同的密码即为root用户的密码

3、为zorke用户添加sudo权限

    sudo visudo
    #添加zorke    ALL=(ALL) ALL


4、破解软件地址

* [http://xclient.info](http://xclient.info)
* [https://www.waitsun.com/](https://www.waitsun.com/)