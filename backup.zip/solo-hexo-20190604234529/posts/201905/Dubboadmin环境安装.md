title: Dubbo-admin环境安装
date: '2019-05-19 11:48:46'
updated: '2019-05-19 11:48:46'
tags: [Dubbo]
permalink: /articles/2019/05/19/1558237726726.html
---
![](https://img.hacpai.com/bing/20180913.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541172357071](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541172357071)

### 背景
&nbsp;&nbsp;本文主要是介绍利用dubbo-admin源码，进行编译打包、安装部署、启动使用的步骤！

**一、dubbo-admin源码下载**

Github地址：[https://github.com/apache/incubator-dubbo](https://github.com/apache/incubator-dubbo)

注意：master和2.6.x分支上是没有dubbo-admin模块的，源码clone到本地之后，将其切换至2.5.x分支（以及tags可以选择到最新的2.5.10）

  

**二、dubbo-admin源码编译打包**

    cd ${dubbo-source-code-path}/incubator-dubbo/dubbo-admin
    mvn package -Dmaven.skip.test=true

若打包不报错则当前目录target下的dubbo-admin-2.5.10.war即成功打包后的dubbo admin管理平台war包

  

**三、启动部署dubbo-admin**

    cp dubbo-admin-2.5.10.war ~/apache-tomcat-9.0.6-dubbo-admin/webapps/
    
    vim ~/apache-tomcat-9.0.6-dubbo-admin/conf/server.xml #将tomcat端口不妨更改为7090，避免冲突
    <Connector port="7090" protocol="HTTP/1.1"
               connectionTimeout="20000"
               redirectPort="8443" />

    cat ~/apache-tomcat-9.0.6-dubbo-admin/webapps/dubbo-admin-2.5.10/WEB-INF/dubbo.properties  #查看默认登录密码

    cd ~/apache-tomcat-9.0.6-dubbo-admin/bin/ & ./startup.sh  #启动tomcat即可

本地访问[http://localhost:7090/dubbo-admin-2.5.10/](http://localhost:7090/dubbo-admin-2.5.10/)，，输入dubbo.properties中的用户及密码(默认root，root)，即可查看dubbo-admin的控台管理页面

登录页面成功且可以看到zookeeper成功连接如下：

![](https://img-blog.csdn.net/2018070313522522?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3pvcmtlQWNjb3VudA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
注意：

    启动部署dubbo-admin之前，需要先在本地启动zookeeper（若非本地的zookeeper，则同样可在dubbo.properties中更改其zk的地址即可）

    关于zookeeper的安装，本文采用docker进行安装和启动，如下：

    docker pull zookeeper:latest
    docker run -d --name zookeeper --publish 2181:2181 --volume ~/docker/zookeeper/data:/data zookeeper:latest
    docker start zookeeper