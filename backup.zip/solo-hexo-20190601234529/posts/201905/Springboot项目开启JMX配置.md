title: Springboot项目开启JMX配置
date: '2019-05-19 11:35:52'
updated: '2019-05-19 11:35:52'
tags: [Springboot]
permalink: /articles/2019/05/19/1558236952113.html
---
![](https://img.hacpai.com/bing/20181105.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/18/1542542580287](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/18/1542542580287)

### 背景
&nbsp;&nbsp;&nbsp;&nbsp;本文主要是介绍在springboot项目中开启JMX配置，以及有关JMX的设置和使用！

1、java spring boot项目开启jmx配置

配置环境变量：


export JAVA_OPTS='-[Djava.rmi.server.hostname=192.168.2.3](Djava.rmi.server.hostname=192.168.2.39)9\[ip\] -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=1099 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false'

  

启动应用jar包：

nohup java $JAVA_OPTS -jar ……………………

  

jconsole或者jvisualvm远程访问：

192.168.2.39 1099