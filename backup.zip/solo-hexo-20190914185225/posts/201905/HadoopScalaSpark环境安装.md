title: Hadoop-Scala-Spark环境安装
date: '2019-05-19 11:47:56'
updated: '2019-05-19 11:47:56'
tags: [BigData]
permalink: /articles/2019/05/19/1558237676787.html
---
![](https://img.hacpai.com/bing/20180818.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541172452468](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541172452468)

### 背景
&nbsp;&nbsp;本文主要是介绍大数据基础设施软件Hadoop-Scala-Spark的安装过程，以macOS、linux等系统环境为例进行实践！

**一、背景**

    在最新的项目开发过程中，需要大量的对基础数据的转换实现中间字段或者中间表，使用SQL去进行数据的计算和处理，往往需要耗费大量的精力去写SQL并且实现起来很不方便，没有R、Python、Matlab、Scala等实现起来方便，基于这样的一个工作过程中遇到的痛点背景，有同学建议使用spark进行数据的etl处理直接生成结果表，先不论能否实现最终的目标但不尝试根本就不会知道是否可以实现，因此先把一个基础的环境搭建起来，至于怎么用怎么样设计好一套流程和环境实现“一劳永逸”（软件领域没有什么是一劳永逸的）那就慢慢来吧！

**二、实践-环境安装（macOS）**

    1、版本：

    jdk：1.8.0_161

    hadoop：3.0.0

    2、安装hadoop

    (1)配置ssh：ssh-keygen -t rsa   =>  一直enter  =>  cat ~/.ssh/id\_rsa.pub >> ~/.ssh/authorized\_keys =>  确认mac已关闭防火墙和开启远程登录(系统偏好设置下：安全与隐私=>防火墙 关闭 ；共享 => 远程登录 打钩)

    (2)brew下载安装hadoop：brew install hadoop   =>   可以查看到/usr/local/Cellar/hadoop/3.0.0已经安装的hadoop位置

    (3)配置hadoop-env.sh ： vim /usr/local/Cellar/hadoop/3.0.0/libexec/etc/hadoop/hadoop-env.sh  =>  将

    # export HADOOP_OPTS="-Djava.net.preferIPv4Stack=true -Dsun.security.krb5.debug=true -Dsun.security.spnego.debug"


后添加

    export HADOOP_OPTS="$HADOOP_OPTS -Djava.net.preferIPv4Stack=true -Djava.security.krb5.realm= -Djava.security.krb5.kdc="
    export JAVA_HOME="/Library/Java/JavaVirtualMachines/jdk1.8.0_161.jdk/Contents/Home"


 （4）配置core-site.xml【hdfs地址和端口】：vim /usr/local/Cellar/hadoop/3.0.0/libexec/etc/hadoop/core-site.xml  =>  添加配置

    <configuration>
       <property>
          <name>hadoop.tmp.dir</name>
          <value>/usr/local/Cellar/hadoop/hdfs/tmp</value>
         <description>A base for other temporary directories.</description>
       </property>
       <property>
         <name>fs.default.name</name>
         <value>hdfs://localhost:8020</value>
       </property>
    </configuration>
      
并且建立文件夹 mkdir /usr/local/Cellar/hadoop/hdfs  & mkdir /usr/local/Cellar/hadoop/hdfs/tmp

    (5)配置mapred-site.xml【mapreduce和jobtracker的地址和端口】：

先备份：cp /usr/local/Cellar/hadoop/3.0.0/libexec/etc/hadoop/mapred-site.xml mapred-site-bak.xml 

再编辑：vim /usr/local/Cellar/hadoop/3.0.0/libexec/etc/hadoop/mapred-site.xml  =>  添加配置

    
    <configuration>
          <property>
            <name>mapred.job.tracker</name>
            <value>localhost:8021</value>
          </property>
    </configuration>

    (6)配置hdfs-site.xml【修改hdfs备份数】：vim /usr/local/Cellar/hadoop/3.0.0/libexec/etc/hadoop/hdfs-site.xml  =>  添加配置
    <configuration>
       <property>
         <name>dfs.replication</name>
         <value>1</value>
        </property>
    </configuration>

   (7)格式化hdfs文件系统格式：hdfs namenode -format

   (8)启动及关闭hadoop服务：

   /usr/local/Cellar/hadoop/3.0.0/libexec/start-dfs.sh  =>  守护进程：namenodes、datanodes、secondary namenodes，浏览器中访问[http://localhost:9870](http://localhost:9870) ,注意端口号是9870而不是50070

   /usr/local/Cellar/hadoop/3.0.0/libexec/start-yarn.sh  =>  yarn服务进程：resourcemanager、nodemanagers，浏览器中访问[http://localhost:8088](http://localhost:8088) 和 [http://localhost:8042](http://localhost:8042)

   /usr/local/Cellar/hadoop/3.0.0/libexec/stop-yarn.sh

   /usr/local/Cellar/hadoop/3.0.0/libexec/stop-dfs.sh

    3、安装scala

    brew下载安装scala：brew install scala   =>   可以查看到/usr/local/Cellar/scala/2.12.5存在或scala -version查看版本 

    4、安装spark

    spark官网下载，下载的时候注意查看其需要依赖的hadoop版本是否满足，下载后mac下直接用解压软件解压并将解压后的文件mv至/usr/local下也即/usr/local/spark-2.3.0-bin-hadoop2.7

    cd /usr/local/spark-2.3.0-bin-hadoop2.7/bin & spark-shell

    5、系统环境变量~/.bash_profile，便于在任何目录下执行一些命令

    vim ~/.bash_profile，添加

    export HADOOP_HOME=/usr/local/Cellar/hadoop/3.0.0/libexec
    export PATH=$PATH:$HADOOP_HOME/sbin:$HADOOP_HOME/bin
    
    export SCALA_HOME=/usr/local/Cellar/scala/2.12.5
    export PATH=$PATH:$SCALA_HOME/bin
    
    export SPARK_HOME=/usr/local/spark-2.3.0-bin-hadoop2.7
    export PATH=$PATH:$SPARK_HOME/bin


注意：brew方式安装的hadoop3.0.0，需要配置的hadoop路径是libexec下的，否则start-dfs.sh命令会报错“error:cannot execute hdfs-config”

    6、日常启动关闭命令：

    start-dfs.sh
    start-yarn.sh
    spark-shell
    stop-yarn.sh
    stop-dfs.sh


以上是hadoop-scala-spark在mac下的安装过程，为昨天在mac下首次实践，一次性成功 => 希望能够对各位同学有所帮助，和得到各位同学的后续关注，如果疑问或者遇到的坑，欢迎在文章下面留言！！

  

[spark开启之路](https://spark.apache.org/docs/latest/quick-start.html)：[https://spark.apache.org/docs/latest/quick-start.html](https://spark.apache.org/docs/latest/quick-start.html)