title: Java - Redis
date: '2019-05-19 11:18:34'
updated: '2019-05-19 11:18:34'
tags: [Java, Redis]
permalink: /articles/2019/05/19/1558235914565.html
---
![](https://img.hacpai.com/bing/20180720.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/12/25/1545748353696](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/12/25/1545748353696)

### 背景
&nbsp;&nbsp;&nbsp;&nbsp;本文主要是记录在学习 Java - Redis 过程中的一些知识点备忘！

20181225

1、概述

Redis一个非关系型内存数据库，存写速度非常之快，被广泛用于缓存方向；也经常用来用作分布式锁，提供多种数据类型（字符串、散列、列表、集合、有序集合等等），且支持事务、持久化、LUA脚本、LRU驱动事件、多种集群方案

2、为什么使用redis而不用map/guava做缓存？

缓存分为本地缓存和分布式缓存！

若使用map或guava实现的是本地缓存，最主要的特点是轻量和快速，但是生命周期随着JVM的销毁而结束，并且在多实例的情况下，每个实例都需要各自保存一份缓存，缓存不具有一致性

而redis或memcached，为分布式缓存；在多实例的情况下，各实例共用一份缓存数据，缓存具有一致性；缺点就是需要保持Redis或memcached的高可用，程序架构上较为复杂

![redis å memcached çåºå«](https://camo.githubusercontent.com/f51fdf878ceaedb4c6d6df7d568ca718d2e327f6/687474703a2f2f6d792d626c6f672d746f2d7573652e6f73732d636e2d6265696a696e672e616c6979756e63732e636f6d2f31382d392d32342f36313630333137392e6a7067)

3、Redis常见数据结构

* String

**常用命令:**set,get,decr,incr,mget 等。

String数据结构是简单的key-value类型，value其实不仅可以是String也可以是数字，常规key-value缓存应用；常规计数：微博数、粉丝数等

* Hash

**常用命令：**hget,hset,hgetall 等。

Hash是一个String类型的field和value的映射表，hash特别适合用于存储对象，在后续操作的时候可以直接仅仅修改这个对象中的某个字段的值。比如，可以用Hash数据结构用来存储用户信息、商品信息等等，示例：

```java
    key=JavaUser293847
    value={
      “id”: 1,
      “name”: “SnailClimb”,
      “age”: 22,
      “location”: “Wuhan, Hubei”
    }
```

* List

**常用命令:**lpush,rpush,lpop,rpop,lrange等。

List是链表，Redis List应用场景非常多，也是Redis最重要的数据结构之一，比如微博的关注列表、粉丝列表、消息列表等功能都可以用Redis和List结构来实现

Redis list的实现为一个双向链表，即可以支持反向查找和遍历，更方便操作，不过带来了部分额外的内存开销

另外，可以通过lrange命令，就是从某个元素开始读取多少个元素，可以基于list实现分页查询，这是一个非常棒的功能，基于redis实现简单的高性能分页，就可以做类似微博那种下拉不断分页的东西（一页一页的往下走），性能高

* Set

**常用命令：**sadd,spop,smembers,sunion 等

Set对外提供的功能与List类似，也是一个列表的功能，特殊之处在于set是可以自动排重的

当需要存储一个列表数据，又不希望出现重复数据时，set是一个很好的选择，且set提供了判断某个成员是否在一个set集合内的重要接口，这也是list所不能提供的；可以基于set轻易实现交集、并集、差集的操作

比如：在微博应用中，可以将一个用户所有的关注人存在一个集合中，将其所有粉丝存在一个集合。Redis可以非常方便地实现如共同关注、共同粉丝、共同喜好等功能，这个过程也就是求交集的过程；具体命令如下：

```java
sinterstore key1 key2 key3     将交集存在key1内
```

* Sorted Set

**常用命令：**zadd,zrange,zrem,zcard等

相比较于Set，sorted set增加了一个权重参数score，使得集合中的元素能够按score进行有序排列

举例：在直播系统中，实时排列信息包含直播间在线用户列表，各种礼物排行榜，弹幕消息（可以理解为按消息维度的消息排行榜）等信息，适合使用Redis中的SortedSet结构进行存储





说明：本JavaGuide系列博客为来源于[https://github.com/Snailclimb/JavaGuide](https://github.com/Snailclimb/JavaGuide)
等学习网站或项目中的知识点，均为自己手打键盘系列且内容会根据继续学习情况而不断地调整和完善！