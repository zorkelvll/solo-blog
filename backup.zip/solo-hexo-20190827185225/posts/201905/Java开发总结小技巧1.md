title: Java开发总结-小技巧1
date: '2019-05-19 11:43:03'
updated: '2019-05-19 11:43:03'
tags: [Java]
permalink: /articles/2019/05/19/1558237383008.html
---
![](https://img.hacpai.com/bing/20180614.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/14/1542125735267](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/14/1542125735267)

### 背景
&nbsp;&nbsp;本文主要是介绍在java开发过程中遇到的、看到的、学到的、总结的一些小技巧，进行记录和随时查看之！在这个小技巧1开篇中第一个例子讲述的场景是java中断言参数是否为数字or数值形式的字符串……


二、日期相关类

1、获取当前周\\上一周\\下一周的周一~周日

    public String takeMonday() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY); //周一~周日
        Date date = cal.getTime();
        //cal.add(Calendar.DATE,-7);//上一周
        //cal.add(Calendar.DATE,7);//下一周
        return sdf.format(date);
    }

2、获取当前日期String形式

    public String today(){
        return LocalDate.now() + "";
    }



一、断言参数是否为数字or数值形式的字符串

1、断言String类型参数的值是否是数字或者数值

    //断言数值类型，如非整数、非浮点数等非数值字符串则会报异常！
    protected void assertBigDecimal(String aValue, String aMsg) {
        try {
            new BigDecimal(aValue);
        } catch (Exception e) {
            throw new IllegalStateException(aMsg);
        }
    }

2、断言String类型参数的值是否是数字

    //断言数字类型，如非整数（即使如12.15也会异常）则会报异常！
    protected void assertNumber(String aValue, String aMsg) {
        try {
            Long.valueOf(aValue);
        } catch (Exception e) {
            throw new IllegalStateException(aMsg);
        }
    }