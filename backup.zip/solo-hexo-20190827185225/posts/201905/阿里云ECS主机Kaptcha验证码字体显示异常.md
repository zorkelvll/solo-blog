title: 阿里云ECS主机-Kaptcha验证码字体显示异常
date: '2019-05-19 11:25:43'
updated: '2019-05-19 11:25:43'
tags: [运维]
permalink: /articles/2019/05/19/1558236343155.html
---
![](https://img.hacpai.com/bing/20180414.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

<br />
<br />
<br />

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/12/02/1543722583847](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/12/02/1543722583847)

### 背景
&nbsp;&nbsp;&nbsp;&nbsp;最近在一台阿里云ECS服务器CentOS7.4上部署应用程序，发现Kaptcha验证码字体显示异常，如下
![imagepng](https://img.hacpai.com/pipe/zorke/zorke/zorke/2fc3ff44a7ec40e8a35f90207e0ba191.png)
&nbsp;&nbsp;&nbsp;&nbsp;经分析排查，该验证码在windows及mac下本地前端页面显示正常，并且在后端服务器中生成验证码的地方将其以文件的形式生成去查看文件也是正常的 =》因此，分析应该是系统环境字体的问题，先将解决办法记录如下：

1、确认部署环境CentOS7.4的默认字体是msam10.ttf

    fc-macth #可查看默认字体，且字体文件在/usr/share/fonts/lyx目录下

2、重命名 msam10.ttf 或者 删除；

文件路径：/usr/share/fonts/lyx/msam10.ttf 

3、重新启动工程包即可解决文件

<br />
<br />
<br />