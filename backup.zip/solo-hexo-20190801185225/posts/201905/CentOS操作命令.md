title: CentOS操作命令
date: '2019-05-19 11:51:22'
updated: '2019-05-19 11:51:22'
tags: [CentOS]
permalink: /articles/2019/05/19/1558237882236.html
---
![](https://img.hacpai.com/bing/20180111.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541172085663](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541172085663)

### 背景
&nbsp;&nbsp;本文主要是记录一些常用的且经常性记不住的linux-centOS下的操作命令，需要说明的是本文仅是记录个人常常忘记的命令，供自己查找和记忆起来更加方便，因此与道友们具有个体差异性，仅供参考！

#### 1、防火墙
```
systemctl status firewalld #查看防火墙firewalld状态
systemctl start firewalld  #开启防火墙firewalld
systemctl stop firewalld   #关闭防火墙firewalld
firewall-cmd --reload      #重启防火墙 或者 systemctl restart firewalld.service
```

#### 2、端口
```
firewall-cmd --list-ports #查看已开放端口
firewall-cmd --zone=public --add-port=80/tcp --permanent #开启80端口
firewall-cmd --reload #重启防火墙以使得开启的80端口生效
firewall-cmd --zone= public--remove-port=80/tcp --permanent #删除80端口配置
    
netstat -lntp #查看监听的端口
netstat -lnp | grep 8080 #查看8080端口被哪个进程占用
```

#### 3、磁盘
```
mount /dev/vdb1 /opt #单次挂载磁盘，机器reboot之后将失效并需要重新挂载

#永久挂载
vim /etc/fstab  #添加如下
/dev/vdb1 /opt ext4 defaults 1 1
```

```
du jdk-8u181-linux-x64.tar.gz -h #查看文件或文件夹占用空间大小
```

#### 4、Vim
```
G   #跳至最后一行
gg  #跳至第一行
n   #配合/实现搜索，表示下一个；#表示搜索上一个
```

#### 5、top
```
top
#按e将使用内存单位依次切换m,g……
#按M则根据内存使用大小排序
echo 3 > /proc/sys/vm/drop_caches  #清除无效占用的buff/cache内存
```

#### FINAL、tips
```
curl ifconfig.me #查看本机外网ip地址
reboot now #系统重启
```