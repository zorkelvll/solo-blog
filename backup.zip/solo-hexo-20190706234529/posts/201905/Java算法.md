title: Java - 算法
date: '2019-05-19 11:12:56'
updated: '2019-05-19 11:12:56'
tags: [Java]
permalink: /articles/2019/05/19/1558235576469.html
---
![](https://img.hacpai.com/bing/20180128.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

<br />
<br />
<br />
### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2019/01/15/1547544162243](https://zorkelvll.cn/blogs/zorkelvll/articles/2019/01/15/1547544162243)

### 背景

&nbsp;&nbsp;&nbsp;&nbsp;本文主要是记录在学习 Java - 算法 过程中的一些知识点备忘！

# 20190115
## 一、排序
### 1、快速排序
* 稳定：No
* 时间复杂度：
    * 最优时间：O(nlog(n))
    * 最坏时间：O(n^2)
    * 平均时间：O(nlog(n))

### 2、归并排序
* 归并排序是典型的分治算法，它不断地将某个数组分为两个部分，分别对左子数组与右子数组进行排序，然后将两个数组合并为新的有序数组
* 稳定：Yes
* 时间复杂度：
    * 最优时间：O(nlog(n))
    * 最坏时间：O(nlog(n))
    * 平均时间：O(nlog(n))

### 3、桶排序
* 桶排序是将数组分到有限数量的桶子里。每个桶子再个别排序（有可能再使用别的排序算法或是以递归方式继续使用桶排序进行排序）

<br />
<br />
<br />