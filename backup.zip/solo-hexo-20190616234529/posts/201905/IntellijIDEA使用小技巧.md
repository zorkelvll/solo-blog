title: Intellij IDEA使用小技巧
date: '2019-05-19 11:38:17'
updated: '2019-05-19 11:38:17'
tags: [IDE]
permalink: /articles/2019/05/19/1558237097710.html
---
![](https://img.hacpai.com/bing/20180919.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

</br>
</br>
</br>
</br>
**关键词：**Intellij IDEA、MAC、Windows、快键键、插件

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/17/1542462501266](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/17/1542462501266)

### 背景
&nbsp;&nbsp;&nbsp;&nbsp;本文主要是记录一些在使用Intellij IDEA进行开发的过程中的，一些小技巧在此处进行记录，以随时备自己查找之用！

## 一、快捷键
#### 1、MAC
* 代码补全：control + space + space (注意，在mac下会与输入法切换默认快捷键冲突，因此可将输入法切换快键键设置为control + ,)
* implements：command + N
* 优化导入包： control + option + o  【file -> settings -> 搜索auto import 并在java下勾选 add unambiguous...和optimize imports on...】
* 格式化代码：control + option + l


## 二、设置

#### 1、新建文件时，自动添加作者、时间等注释信息设置

* Ctrl+Alt+S（windows）或者“Preferences - Editor - File and Code Templates - Includes - File Header”
* 设置对应的文件注释信息,如：

```java
/**  
*     
* @author `<a href="mailto:zhaoke_cai@163.com">zorke</a>`  
*     
* @date ${DATE}  
*     
* @description :  
*     
*/
```

#### 2、在序列化类中提示添加serialVersionUID，并使用快键键快速创建：

    IDEA默认未开启该提示功能，Preferences->Editor->Inspections->Serialization issues->Serializable class without ’serialVersionUID’勾上，则开启了检测功能（光标移至类名上会弹出提示）

    在class类名前**（注意一定需要将光标移动至类名前）**，使用快捷键（**Mac:option+return**）或者( Win:Alt+Enter)  根据提示自动创建serialVersionUID

    注意：上述的检测提示功能和快键键生成serialVersionUID的功能，在都需要设置好的IDEA重启之后才可以生效


#### 3、编译项目报错Error:java: Compilation failed: internal java compiler error

File --setting--compiler--Java Compiler选择相应当前系统jdk的版本如1.8选择1.8即可​​​


</br>
</br>
</br>
</br>