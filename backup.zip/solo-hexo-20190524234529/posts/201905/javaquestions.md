title: java - questions
date: '2019-05-19 11:13:26'
updated: '2019-05-19 11:13:26'
tags: [Java]
permalink: /articles/2019/05/19/1558235606686.html
---
![](https://img.hacpai.com/bing/20180208.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

<br />
<br />
<br />
### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2019/01/14/1547480254078](https://zorkelvll.cn/blogs/zorkelvll/articles/2019/01/14/1547480254078)

### 背景

&nbsp;&nbsp;&nbsp;&nbsp;本文主要是记录一些java后端常见的一些问题及简要回答，详解可参见相关其他博文即可！

20190114

<br />
<br />
<br />