title: Zookeeper环境安装
date: '2019-05-19 11:44:59'
updated: '2019-05-19 11:44:59'
tags: [Zookeeper]
permalink: /articles/2019/05/19/1558237499546.html
---
![](https://img.hacpai.com/bing/20180215.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/12/1542036943367](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/12/1542036943367)

### 背景
&nbsp;&nbsp;本文主要介绍zookeeper环境在linux-centos、macos、windows等各个平台的单机模式、伪集群模式、集群模式的安装手册！

**注意：**ZooKeeper的安装需要先安装JDK, 关于JDK的安装及配置这里不再赘述！

一、CentOS7.2下单机模式安装

1、安装zookeeper

    cd ~/app && wget http://mirror.bit.edu.cn/apache/zookeeper/zookeeper-3.4.13/zookeeper-3.4.13.tar.gz    #下载zookeeper文件
    tar -zxvf zookeeper-3.4.13.tar.gz  ##解压文件
    cd zookeeper-3.4.13/conf/ && cp zoo_sample.cfg  zoo.cfg #修改相关配置，比如：
    #dataDir=/root/data/zkDataDir
    #dataLogDir=/root/logs/zkLogDir
    cd ../bin/ && zkServer.sh start  #启动zk
    firewall-cmd --zone=public --add-port=2181/tcp --permanent #开放2181端口
    firewall-cmd --reload #刷新防火墙端口

2、安装zkui图形界面管理zookeeper

    git clone https://github.com/DeemOpen/zkui.git #clone源代码
    cd zkui && mvn clean install
    #mvn编译构建成功zkui之后，会出现zkui-2.0-SNAPSHOT.jar和zkui-2.0-SNAPSHOT-jar-with-dependencies.jar，区别在于前者运行时需要额外的第三方jar包而后者是可以直接运行的
    cp config.cfg ./target/ && vim config.cfg  #修改zkui的配置,端口号、zk地址、用户名密码、数据库地址(默认H2)
    nohup java -jar zkui-2.0-SNAPSHOT-jar-with-dependencies.jar >zkui-out.log 2>&1 &
    #java -jar target/zkui-2.0-SNAPSHOT-jar-with-dependencies.jar #启动zkui
    firewall-cmd --zone=public --add-port=“config.cfg中的端口号”/tcp --permanent #开放2181端口
    firewall-cmd --reload #刷新防火墙端口
    #浏览器中访问 IP+端口  输入用户名密码即可登录web图形页面查看zookeeper
    #说明：如果使用mysql记得先去创建数据库如zkui，且如果有问题可以在target下查看log，如果使用mysql记得配置相关scm配置以获取相关依赖若仍然失败请先使用默认的H2数据库尝试一下是否成功


二、CentOS7.2下伪集群模式&集群模式安装