title: Spring容器
date: '2019-05-19 11:32:58'
updated: '2019-05-19 11:32:58'
tags: [Spring]
permalink: /articles/2019/05/19/1558236777995.html
---
![](https://img.hacpai.com/bing/20180501.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

关键词：**Spring容器、BeanFactory、ApplicationContext**

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/18/1542543148853](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/18/1542543148853)


一、容器

     在Java中，如果有一个类是**专门用来存放其他类的对象的**，那么这个类就叫做**容器**（或者集合，集合就是将若干个性质相同或相近的类对象组合在一起而形成的一个整体）

    Java容器类：List、ArrayList、Vector、Map、Hashtable、HashMap等

    Spring容器：ApplicationContext

    web容器：tomcat、webLogic、webSphere、Resin

  

二、Spring容器

**1、概述 **

     Spring提供容器功能，专门用来**存放和管理应用中各对象的生命周期、对象间的依赖关系**；

     **Spring容器**是Spring的核心，一切SpringBean均存储在Spring容器内，并通过**Ioc技术**（->因此也称**SpringIOC容器**）进行管理；Spring容器是一个**bean工厂（BeanFactory）**，应用中**各bean的实例化、获取、销毁等均由这个bean工厂管理**；

    简言之，Spring容器就是一个Java编写的程序，之前必须由应用自身编写逻辑代码以管理对象及对象间关系，现在将都由这个程序（容器）自动管理维护。

**2、是什么**

    在Spring中，org.springframework.context.**ApplicationContext接口用于完成容器的配置、初始化、管理bean**；而把某个**实现了ApplicationContext接口的类的实例，就称之为一个Spring容器**，也即从代码层面"Spring容器就是一个**ApplicationContext**"

    在一般java工程中，可通过代码显示new一个**ClassPathXmlApplicationContext**或**FileSystemXmlApplicationContext**以初始化一个Spring容器；

    在web工程中，一般通过在web.xml中配置的方式以初始化一个Spring容器

**3、Web工程的Spring配置**

    **context-param：**contextConfigLocation指定Spring容器初始化时读取**配置文件的位置**

    **listener：**ContextLoaderListener类（->该类是标准SpringWeb工程中Spring开始干活的切入点，这是因为该类实现了ServletContextListener，在web容器启动时该类将对Spring容器进行初始化）用于启**动web容器**（如tomcat）去读取配置文件并**完成Spring容器的初始化**

**4、SpringIOC容器初始化过程：**

    SpringIOC容器启动时，先读取**应用程序提供的Bean配置信息**（XML、Java类@Configuration、注解@Autowire），然后在Spring容器中生成一份**Bean配置注册表**，然后根据Bean注册表**实例化Bean和装配好Bean间依赖关系**，并将各Bean实例**放入到Spring容器(Bean缓存池**，基于HashMap实现) -> 上层应用即可**使用**这些Bean实例