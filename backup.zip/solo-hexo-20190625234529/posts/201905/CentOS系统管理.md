title: CentOS系统管理
date: '2019-05-19 11:46:38'
updated: '2019-05-19 11:46:38'
tags: [CentOS]
permalink: /articles/2019/05/19/1558237598032.html
---
![](https://img.hacpai.com/bing/20180909.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/08/1541688065445](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/08/1541688065445)

### 背景
&nbsp;&nbsp;&nbsp;&nbsp;本文主要是介绍在Linux-CentOS系统（以CentOS7.2版本为例）中进行管理的一些操作记录及命令，以备用学习之！

1、查看命令

    uname -a                   #系统信息
    cat /etc/redhat-release    #操作系统版本号
    cat /proc/cpuinfo          #CPU信息
    env                        #系统环境变量
    free -m                    #系统内存及交换分区使用情况
    df -h                      #各分区使用情况
    uptime                     #系统运行时间，用户数，负载情况
    w                          #查看活跃用户
    last                       #用户登录日志
    crontab -l                 #用户计划任务
    chkconfig --list           #系统服务状态
    rpm -qa                    #已安装软件包

    df -hl #查看磁盘使用情况以及剩余情况等
    du -sh * #显示当前目录下各文件及文件夹大小
    du -sh * | sort -nr  #显示大小并按照大小倒序

2、创建用户组及用户

    groupadd aokay  #用户组aokay  
    cd / && chgrp -R aokay /opt/ #为用户组aokay分配根目录opt
    chmod 777 opt    #为用户组根目录opt设权限
    mkdir -m 775 /opt/app && chgrp -R aokay /opt/  #为用户组所有用户分配公共应用目录app


    useradd -g aokay -d /opt/zorke zorke  #为用户组aokay添加用户zorke
    passwd zorke  #为用户zorke设置密码
    #chmod 755 /etc/sudoers  #【当前操作用户为root用户下无需此操作】
    echo "devops ALL=(ALL:ALL) NOPASSWD: ALL" >> /etc/sudoers #添加管理员权限
    #chmod 440 /etc/sudoers  #【当前操作用户为root用户下无需此操作】
 
    su zorke
    cd ~

3、工具安装

    yum install git  #安装git
    wget -qO- https://raw.githubusercontent.com/creationix/nvm/v0.33.11/install.sh | bash #安装nvm，重新打开shell窗口即可使用nvm或者使用curl
    #curl -o- https://raw.githubusercontent.com/creationix/nvm/v0.33.11/install.sh | bashcommand -v nvm  #安装nvm，重新打开shell窗口即可使用nvm