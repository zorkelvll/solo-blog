title: Redis环境安装
date: '2019-05-19 11:49:46'
updated: '2019-05-19 11:49:46'
tags: [Redis]
permalink: /articles/2019/05/19/1558237786276.html
---
![](https://img.hacpai.com/bing/20171204.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541172303711](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541172303711)

### 背景
&nbsp;&nbsp;本文主要在Linux-CentOS环境下源码安装运行Redis4.0.11，以及redis配置文件管理、设置密码、开放外网访问等,以及yum安装方式！

**一、CentOS7.2下源码安装及运行redis4.0.11**

1、下载&解压：

    cd ~/app
    wget http://download.redis.io/releases/redis-4.0.11.tar.gz
    tar -zxvf redis-4.0.11.tar.gz


2、编译

    cd redis-4.0.11/src/
    yum install gcc-c++ tcl
    make
    make test
    
    注意：
    执行make的时候，可能会出现异常
      异常一：
                make[2]: cc: Command not found
                异常原因：没有安装gcc
                解决方案：yum install gcc-c++
      异常二：
               zmalloc.h:51:31: error: jemalloc/jemalloc.h: No such file or directory
               异常原因：一些编译依赖或原来编译遗留出现的问题
               解决方案：make distclean。清理一下，然后再make。
    
     在make成功以后，需要make test。在make test出现异常。
      异常一：
              couldn't execute "tclsh8.5": no such file or directory
              异常原因：没有安装tcl
              解决方案：yum install -y tcl
    

3、配置

（1）、make之后src目录下会新加redis-server，redis-cli等可执行文件命令，可将其复制添加至/usr/local下

（2）、新建目录以存放redis配置文件目录，如/etc/redis，/var/redis/log、run、6379等

（3）、将redis解压文件夹中的配置文件redis.conf模板复制都/etc/redis目录下

（4）、修改redis.conf中的配置项

daemonize yes
 
pidfile /var/redis/run/redis_6379.pid

logfile /var/redis/log/redis_6379.log

dir /var/redis/6379
    
    cp redis-server /usr/local/bin/ & cp redis-cli /usr/local/bin/
    mkdir /etc/redis & mkdir /var/redis
    mkdir /var/redis/log & mkdir /var/redis/run & mkdir /var/redis/6379
    
    cp redis.conf /etc/redis/6379.conf
    vim /etc/redis/6379.conf

4、运行

    redis-server /etc/redis/6379.conf &

**二、yum安装redis**

    #centos7
    yum -y install redis
    systemctl enable redis
    systemctl start redis

    # centos6
    yum -y install redis
    chkconfig redis on
    service redis start


**三、设置密码和开发外网访问**

    #1、设置远程访问
    vim redis.conf
    #bind 127.0.0.1  #注释掉bind 127.0.0.1
    bind 0.0.0.0  #添加bind 0.0.0.0
    protected-mode no #将protected-mode yes修改为protected-mode no

    #2、修改密码
    vim redis.conf
    requirepass 你的密码 #设置密码，建议给予非常复杂的密码，redis有漏洞

    #3、修改端口
    vim redis.conf
    port 6379
    mv redis.conf /etc/redis/6379.conf
    redis-server /etc/redis/6379.conf &

    


**四、Mac下安装redis**

Mac下安装Redis 使用home-brew

一键安装：brew install redis 

启动Redis服务：brew services start redis 或 redis-server /usr/local/etc/redis.conf 

#redis-server /usr/local/etc/redis.conf &

关闭Redis服务：brew services stop redis 

重启Redis服务：brew services restart redis 

打开图形化界面：redis-cli

brew services list 查看homebrew安装的的服务