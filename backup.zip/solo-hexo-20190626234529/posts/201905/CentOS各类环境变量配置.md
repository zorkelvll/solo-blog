title: CentOS各类环境变量配置
date: '2019-05-19 11:51:50'
updated: '2019-05-19 11:51:50'
tags: [CentOS]
permalink: /articles/2019/05/19/1558237910149.html
---
![](https://img.hacpai.com/bing/20181001.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541171981714](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541171981714)

### 背景
&nbsp;&nbsp;本文主要是集中记录在Linux-CentOS7.2系统环境下的，常用的一些软件环境变量的配置情况，供查找和参考！

**1、jdk**

```
vim /etc/profile 
#jvm-jdk
JAVA_HOME="/usr/local/jvm/jdk1.8.0_181"
JRE_HOME=${JAVA_HOME}/jre
CLASS_PATH=".:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar"
PATH=".$PATH:$JAVA_HOME/bin"
export JAVA_HOME JRE_HOME CLASS_PATH PATH

```


**2、maven**

    vim /etc/profile 
    export M2_HOME=${HOME}/app/apache-maven-3.5.4
    export PATH=$PATH:$M2_HOME/bin


**3、golang**

    vim /etc/profile 
    export GOROOT=${HOME}/go1.11.1 
    export GOPATH=${HOME}/gopath 
    export GOBIN=${GOPATH}/bin 
    export PATH=${PATH}:${GOBIN}:${GOROOT}/bin
    #其中 gopath 下建目录 pkg,bin,src