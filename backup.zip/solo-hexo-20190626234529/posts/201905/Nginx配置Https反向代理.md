title: Nginx配置Https反向代理
date: '2019-05-19 11:24:11'
updated: '2019-05-19 11:24:11'
tags: [运维, Nginx]
permalink: /articles/2019/05/19/1558236251564.html
---
![](https://img.hacpai.com/bing/20180331.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/12/09/1544347717025](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/12/09/1544347717025)

### 背景
&nbsp;&nbsp;&nbsp;&nbsp;本文主要是记录配置nginx反向代理https过程中的一些记录！

一、Nginx添加SSL模块

nginx默认缺少SSL模块支持，需要手动编译安装！由于本文之前已经编译安装过nginx，因此本文将是在原有基础之上编译安装添加SSL模块

    cd /root/app/nginx-1.14.0   
    /usr/local/nginx/sbin/nginx -V  #查看nginx旧的编译参数
    ./configure [......旧的编译参数仍然保持不变] --prefix=/usr/local/nginx --with-http_ssl_module  #在原有旧的编译参数基础之上添加新的模块--with-http_ssl_module
    make  #注意：千万不能执行make install，否则原来nginx的一堆配置文件将被覆盖
    cp /usr/local/nginx/sbin/nginx ~/    #备份原来的nginx可执行程序
    cp objs/nginx /usr/local/nginx/sbin/  #将新编译的nginx可执行程序objs/nginx复制覆盖原nginx执行程序
    #覆盖之后，重新启动nginx即为新的nginx

二、免费获取SSL证书

    #https://freessl.cn/  #注册freessl账号
    #输入域名以及域名注册的邮箱地址，生成SSL证书
    #到域名所在服务商位置，设置TXT解析以进行域名验证，如下
    #或者aliyun 控台下载免费的域名证书

![imagepng](https://img.hacpai.com/pipe/zorke/zorke/zorke/000d5372e5cf4b1ab30be3a83533cacf.png)

    #在freessl控制台进行域名验证，验证通过之后可以下载证书压缩文件解压之后传输到nginx所在服务器上（full_chain.pem和private.key两个文件）

三、配置nginx

    vim /usr/local/nginx/conf/nginx.conf

    #修改配置付下
    server {
        listen 80;
        server_name caizhaoke.cn,www.caizhaoke.cn;
        rewrite ^(.*)$ https://www.caizhaoke.cn;
    }
    server {
        listen 443 ssl;
        server_name caizhaoke.cn,www.caizhaoke.cn;
        ssl on;
        #SSL-START SSL相关配置，请勿删除或修改下一行带注释的404规则
        ssl_certificate /root/data/cert/full_chain.pem;
        ssl_certificate_key /root/data/cert/private.key;
        ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
        ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE;
        ssl_prefer_server_ciphers on;
        ssl_session_timeout 10m;
        #SSL-END

        index index.jsp index.html;

        location / {
            add_header Content-Security-Policy upgrade-insecure-requests; # for 解决 https 之后静态资源http mixed content问题

            proxy_pass http://pipe$request_uri;
            proxy_set_header Host $host:$server_port;
            proxy_set_header X-Real-IP $remote_addr;
            client_max_body_size 10m;
        }
    }

    /usr/local/nginx/sbin/nginx -t #检测nginx配置文件是否有错误
    /usr/local/nginx/sbin/nginx -s reload #重启nginx 

    #保证服务器以及云服务商的防火墙开启443端口之后，浏览器中访问https即可验证成功