title: ActiveMQ环境安装
date: '2019-05-19 11:28:12'
updated: '2019-05-19 11:28:12'
tags: [运维]
permalink: /articles/2019/05/19/1558236492563.html
---
![](https://img.hacpai.com/bing/20171230.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/19/1542638081786](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/19/1542638081786)

### 背景

&nbsp;&nbsp;本文主要是记录ActiveMQ在CentOS、MacOS等环境下的安装，仅作记录之用！

一、MacOS下brew方式安装

    brew install activemq  
 
    activemq --version #查看版本号
    activemq start #启动activemq服务，本文访问[http://localhost:8161/](http://localhost:8161/)，默认admin，admin
    activemq stop #停止activemq服务