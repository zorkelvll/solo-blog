title: SpringBoot技巧
date: '2019-05-19 10:46:53'
updated: '2019-05-19 11:36:18'
tags: [Springboot]
permalink: /articles/2019/05/19/1558234013429.html
---
![](https://img.hacpai.com/bing/20190329.jpg?imageView2/1/w/768/h/432/interlace/1/q/100)

<br />
<br />
<br />
&nbsp;&nbsp;&nbsp;&nbsp;本文主要是记录自己在使用SpringBoot过程中自认为的一些小技巧！！


### mvn

#### 跳过测试

##### 1、命令
maven package/ install 命令 跳过测试：
``` 
mvn clean package -Dmaven.test.skip=true  #测试类不会生成.class 文件  
mvn clean package -DskipTests   #测试类会生成.class文件

mvn install -Dmaven.test.skip=true  #测试类不会生成.class 文件  
mvn install -DskipTests   #测试类会生成.class文件
```
##### 2、插件
maven-surefire-plugin 插件 跳过测试 配置，需要在pom.xml里加：
```
<configuration>  
  <skipTests>true</skipTests>  
</configuration>  
```
测试类会生成.class文件

spring-boot-maven-plugin 插件 跳过测试 配置，需要在pom.xml里加：
```  
<properties>  
  <skipTests>true</skipTests>
</properties>  
```
测试类会生成.class文件

<br />
<br />
<br />