title: Nginx运维寻坑记
date: '2019-05-19 11:41:58'
updated: '2019-05-19 11:41:58'
tags: [Nginx]
permalink: /articles/2019/05/19/1558237318440.html
---
![](https://img.hacpai.com/bing/20180806.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/14/1542126572569](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/14/1542126572569)

### 背景
&nbsp;&nbsp;本文主要是介绍在Nginx使用运维过程中所遇到的一些坑爹的地方，予自己以做记录，既是为自己后续查找问题提供方便，也是希望能够给各位猿友减少一些踩坑的过程！

### 前言

    经过前一段时间的思考设计与整合，最终为公司目前的所有项目系统的管理员页面设计成了一个单点登录系统（该系统将在后续专门整理专题讲解设计与实现思路），然后今天在将其中的一个项目系统进行上线整合的过程中，对于配置的nginx中踩了个小坑，现在此做一个记录以备后续参考和学习！    

### 正记

#### 入坑3
##### 1、描述
&nbsp;&nbsp;nginx反向代理多个springboot-jar应用，作为统一对外提供的服务网关，而通过nginx在swagger-ui.html页面api文档中发起各个接口请求时，实际请求的地址是127.0.0.1问题
##### 2、解决方案：
&nbsp;&nbsp;在nginx.conf中的配置反向代理时，添加proxy\_set\_header Host $http_host;配置项即可，如
![nginx1.jpeg](https://img.hacpai.com/file/2019/03/nginx1-dfc69bf6.jpeg)

#### 入坑2

##### 1、描述
&nbsp;&nbsp;linux-root用户下配置的nginx，访问页面时报错403 Forbidden，nginx-log显示为Permission denied

##### 2、说明：
&nbsp;&nbsp;nginx配置项中nginx.conf中的用户配置默认为nobody，也即#user  nobody;，而当前用户是root

##### 3、解决方案：
&nbsp;&nbsp;在nginx.conf中的配置**#user  nobody;更改为**user  root;，，，则可以解决！

  

#### 入坑1

##### 1、描述

&nbsp;&nbsp;由postman模拟前端请求的接口中携带的header，java-tomcat后端可以成功获取到；但是在线上的服务器中传输过来的ajax请求携带的header却被服务器的java后端获取到为null，事实上前端F12检查查看到的是实际发送的请求确实是携带有header的，而且ajax的js代码与以前可以正常使用被获取到的js代码是一样的 

##### 2、说明：

*  初步考虑是nginx代理配置的问题，也就是考虑添加配置项： add\_header 'Access-Control-Allow-Headers' 'DNT,X-CustomHeader,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,imf\_token_manager,';  这样的一段配置代码，但是还没有效果

*  进一步研究发现是因为nginx对于header中的字符默认是有限制的，且配置项underscores\_in\_headers默认为off，也即header-name中含有下划线_的将被忽略掉，以致于部署的服务器环境中是没有该header-name 的；在nginx源码的ngx\_http\_parse\_header\_line() 函数中有下面一端代码则可以知道：

```
    if (ch == ‘_’) {
      if (allow_underscores) {
        hash = ngx_hash(hash, ch);
        r->lowcase_header[i++] = ch;
        i &= (NGX_HTTP_LC_HEADER_LEN – 1);
      } else {
        r->invalid_header = 1;
      }
```

##### 3、解决方案：

*  推荐使用：将前后端约定的header-name中的下划线使用其他字符进行代替，比如减号“-”，或者使用驼峰命名法定义header-name

*  不推荐使用：在nginx 的nginx.conf中配置http部分设置**underscores\_in\_headers为on，也即添加“**underscores\_in\_headers:on;**”

* 习惯：在与nginx相关的一些配置或者需要传输或者log记录等过程中，尽量避免使用下划线