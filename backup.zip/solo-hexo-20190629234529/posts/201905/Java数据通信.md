title: Java - 数据通信
date: '2019-05-19 11:18:00'
updated: '2019-05-19 11:18:00'
tags: [Java]
permalink: /articles/2019/05/19/1558235880147.html
---
![](https://img.hacpai.com/bing/20181223.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/12/28/1546000977375](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/12/28/1546000977375)

### 背景
&nbsp;&nbsp;&nbsp;&nbsp;本文主要是记录在学习 Java - 数据通信 过程中的一些知识点备忘！

一、

* RPC：RMI(JDK自带)、Dubbo、Hessian、Thrift
* 消息中间件：ActiveMQ、RabbitMQ、RocketMQ、Kafka、Confluo

20181228

1、RPC

RPC-远程过程调用，是一种通过网络从远程计算机程序上请求服务，而不需要了解底层网络技术的协议。

RPC协议假定某些传输协议的存在，如TCP或UDP，为通信程序之间携带信息数据，用于开发分布式应用程序。在OSI网络通信模型中，RPC跨越了传输层和应用层。

RPC采用客户端（服务调用方）/服务端（服务提供方）模式，都运行在自己的JVM中。客户端只需要引入使用的接口，接口的实现和运行都在服务器端；RPC主要依赖的技术包括序列号、反序列化和数据传输协议，这是一种定义与实现相分离的设计

RPC主要指内部服务之间的调用，RESTful也可以用于内部服务之间的调用但其主要用途还是在于外部系统提供服务

Java中常见的RPC框架有：

* RMI:JDK自带的RPC
* Dubbo:Alibaba开源的一个高性能优秀的RPC服务框架，使得应用间可通过高性能的RPC实现服务的输出和输入功能，可以和Spring框架无缝集成
* Hessian:一个轻量级RPC框架，基于HTTP协议传输，使用简单的方法提供了RMI的功能；相比较于WebService，Hessian更简单、快捷；采用二进制序列化，对数据包比较大情况友好
* Thrift:Facebook开源的跨语言RPC通信框架


如何进行选择？

* 是否允许代码入侵：即需要依赖相应的代码生成器生成代码，比如Thrift
* 是否需要长连接获取高性能：如果对于性能需求较高的话，那么果断可以选择基于TCP的Thrift、Dubbo
* 是否需要跨域网段、跨越防火墙：这种情况一般选择基于HTTP协议的Hessina和Thfrit的HTTP Transport

此外，Google基于HTTP2.0的gRPC框架，其序列号协议基于Protobuf，网络框架使用的是Netty4，但是其需要生成代码，可扩展性也比较差

1.1、RPC-RMI

1.2、RPC-Dubbo

1.3、RPC-Hessian

1.4、RPC- Thrift


2、消息中间件

消息中间件，也叫做中央消息队列或消息队列（区别于本地消息队列，本地消息队列指的是JVM内的队列实现），是一种独立的队列系统；

消息中间件经常用于解决内部服务之间的异步调用问题：请求服务方把请求队列放到队列中即可返回，然后等待服务提供方队列中获取请求进行处理，之后通过回调等机制把结果返回给请求服务方

异步调用仅是消息中间件一个非常常见的应用场景，此外其他的一些常见应用场景有：

* 解耦：一个业务的非核心流程需要依赖其他系统，但结果并不重要，有通知即可
* 最终一致性：指的是两个系统的状态保持一致，可以有一定的延迟，只要最终达到一致性即可。经常用在解决分布式事务上
* 广播：消息队列最基本的功能。生产者只负责生成消息，订阅者接收消息
* 错峰和流控

常见的消息队列有ActiveMQ（性能差，不推荐使用）、RabbitMQ、RocketMQ、Kafka、Confluo等等

2.1、ActiveMQ

2.2、RabbitMQ

2.3、RocketMQ

2.4、Kafka