title: MySQL模糊查询&排序-方案
date: '2019-05-19 11:50:50'
updated: '2019-05-19 11:50:50'
tags: [MySQL]
permalink: /articles/2019/05/19/1558237850124.html
---
![](https://img.hacpai.com/bing/20180107.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541172141731](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/02/1541172141731)

### 背景
&nbsp;&nbsp;本文主要是介绍mysql中对于模糊查询的结果，进行再次排序问题的解决思路，比如模糊查询的结果希望按照“KeyWord”、“KeyWord%”、“%KeyWord”、“%KeyWord%”方式排序,又如希望按照匹配度从高到低进行排序等！

**背景一**
&nbsp;&nbsp;在一些模糊查询的过程中，有一些需求对于查询结果的排序问题，如查询keyWord的值为“万科”，常常需要希望对于模糊查询的结果排序规则最好为“万科”，“万科%”，“%万科”，"%万科%"，一种解决办法是通过编程语言如java中去处理暂且不提，在此则提供一种SQL解决方案，具体sql可参考如下：
        
    <select id="findAllByParam" parameterType="com.idwzx.info.domain.ViewQuickMacroParam"
            resultType="com.idwzx.info.domain.ViewQuickMacroResult">
        SELECT v.type,v.trd_code trdCode,v.name,v.name_py namePy
        FROM V_QUICK_MACRO v
        <include refid="conditionOrAll"/>
        <include refid="limitSql"/>
    </select>
    <sql id="conditionOrAll">
        <where>
            <if test="keyWord != null and keyWord != ''">
                AND (trd_code LIKE concat('%',#{keyWord},'%')
                OR `name` LIKE concat('%',#{keyWord},'%')
                OR name_py LIKE concat('%',#{keyWord},'%'))
                order by
                (case
                when trd_code = #{keyWord} then 10
                when `name` = #{keyWord} then 11
                when name_py = #{keyWord} then 12
                when trd_code like concat(#{keyWord},'%') then 20
                when `name` like concat(#{keyWord},'%') then 21
                when name_py like concat(#{keyWord},'%') then 22
                when trd_code like concat('%',#{keyWord}) then 30
                when `name` like concat('%',#{keyWord}) then 31
                when name_py like concat('%',#{keyWord}) then 32
                when trd_code like concat('%',#{keyWord},'%') then 40
                when `name` like concat('%',#{keyWord},'%') then 41
                when name_py like concat('%',#{keyWord},'%') then 42
                else 50
                end )
            </if>
        </where>
    </sql>
    <sql id="limitSql">
        <if test="limitCount gt 0">
            <![CDATA[ LIMIT #{limitCount} ]]>
        </if>
        <if test="limitCount eq 0">
            LIMIT 50
        </if>
    </sql>


**背景二**

&nbsp;&nbsp;在模糊查询的过程中，根据匹配度进行排序