title: Springboot项目jar包启动
date: '2019-05-19 11:37:17'
updated: '2019-05-19 11:37:17'
tags: [Springboot]
permalink: /articles/2019/05/19/1558237037723.html
---
![](https://img.hacpai.com/bing/20180504.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### ZERO
&nbsp;&nbsp;&nbsp;&nbsp;[持续更新](https://zorkelvll.cn/)  请关注：[https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/18/1542542130054](https://zorkelvll.cn/blogs/zorkelvll/articles/2018/11/18/1542542130054)

### 背景
&nbsp;&nbsp;&nbsp;&nbsp;本文主要是记录在基于springboot进行开发的项目的jar包，在启动以及运维发布维护、配置文件配置等一些技巧或者策略性的实践进行记录！

**1、java -jar XXX.jar**

&nbsp;&nbsp;&nbsp;&nbsp;如果是想使用XXX.jar包源码中默认application.yml中的配置项，则不需要指定参数

-Dspring.config.location=/opt/app/jars/application.yml ，，，且**需要保证当前jar文件所在的目录下不存在application.yml【切记！！！】**